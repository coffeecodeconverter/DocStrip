﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMain))
        Me.Panel_Sources = New System.Windows.Forms.Panel()
        Me.Label_Sources_DocCountValue = New System.Windows.Forms.Label()
        Me.ToolStrip_Sources = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton_ManageSources = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip_Sources_Button_Refresh = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip_Sources_Button_DocInfo = New System.Windows.Forms.ToolStripButton()
        Me.Label_Sources_DocCount = New System.Windows.Forms.Label()
        Me.Panel_Parent_MenustripMain = New System.Windows.Forms.Panel()
        Me.MenuStripMain = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResetApplicationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox_Documents_Source = New System.Windows.Forms.GroupBox()
        Me.DataGridView_Documents_Sources = New System.Windows.Forms.DataGridView()
        Me.Source = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FileType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel_Parent_ToolstripMain = New System.Windows.Forms.Panel()
        Me.ToolStripMain = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.Panel_Parent_Status = New System.Windows.Forms.Panel()
        Me.Panel_StatusMessage = New System.Windows.Forms.Panel()
        Me.Label_StatusMessage = New System.Windows.Forms.Label()
        Me.ProgressBar_Status = New System.Windows.Forms.ProgressBar()
        Me.GroupBox_Documents_DestinationText = New System.Windows.Forms.GroupBox()
        Me.Button_DestinationText_Default = New System.Windows.Forms.Button()
        Me.Panel_DestinationText_RadioButtonsFilename = New System.Windows.Forms.Panel()
        Me.RadioButton_DestinationText_PrependFilename = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DestinationText_CustomFilename = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DestinationText_AppendFilename = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DestinationText_SameOriginFile = New System.Windows.Forms.RadioButton()
        Me.Panel_DestinationText_Filename = New System.Windows.Forms.Panel()
        Me.Label_DestinationText_Filename = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.TextBox_DestinationText_Filename = New System.Windows.Forms.TextBox()
        Me.Panel_DestinationText_RadioButtonsDirectory = New System.Windows.Forms.Panel()
        Me.RadioButton_DestinationText_Custom = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DestinationText_SameOriginFolder = New System.Windows.Forms.RadioButton()
        Me.Panel_DestinationText_Directory = New System.Windows.Forms.Panel()
        Me.Button_DestinationText_Browse = New System.Windows.Forms.Button()
        Me.Label_DestinationText_Directory = New System.Windows.Forms.Label()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.TextBox_DestinationText_Directory = New System.Windows.Forms.TextBox()
        Me.TabControlMain = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox_Documents_DestinationMetadata = New System.Windows.Forms.GroupBox()
        Me.Button_DestinationMetadata_Default = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel_DestinationMetadata_RadioButtons = New System.Windows.Forms.Panel()
        Me.RadioButton_DestinationMetadata_Custom = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DestinationMetadata_SameAsPlainText = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DestinationMetadata_SameOriginFolder = New System.Windows.Forms.RadioButton()
        Me.Panel_DestinationMetadata_Directory = New System.Windows.Forms.Panel()
        Me.Button_DestinationMetadata_Browse = New System.Windows.Forms.Button()
        Me.Label_DestinationMetadata_Directory = New System.Windows.Forms.Label()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.TextBox_DestinationMetadata_Directory = New System.Windows.Forms.TextBox()
        Me.Panel_DestinationMetadata_Checkboxes = New System.Windows.Forms.Panel()
        Me.CheckBox_DestinationMetadata_GenerateMetadata = New System.Windows.Forms.CheckBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox_Options_MetadataCustom = New System.Windows.Forms.GroupBox()
        Me.Panel_MetadataCustom_Toolstrip = New System.Windows.Forms.Panel()
        Me.ToolStrip_MetadataCustom = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton6 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripDropDownButton2 = New System.Windows.Forms.ToolStripDropDownButton()
        Me.ByKeyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ByValueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip_MetadataCustom_Button_SelectAll = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip_MetadataCustom_Button_DeleteSelected = New System.Windows.Forms.ToolStripButton()
        Me.DataGridView_Options_MetadataCustom = New System.Windows.Forms.DataGridView()
        Me.Key = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Value = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox_Options_MetadataCommon = New System.Windows.Forms.GroupBox()
        Me.Button_MetadataCommon_Default = New System.Windows.Forms.Button()
        Me.Button_MetadataCommon_None = New System.Windows.Forms.Button()
        Me.Button_MetadataCommon_SelectAll = New System.Windows.Forms.Button()
        Me.FlowLayoutPanel_MetadataCommonOptions = New System.Windows.Forms.FlowLayoutPanel()
        Me.CheckBox_MetadataCommon_Filename = New System.Windows.Forms.CheckBox()
        Me.CheckBox_MetadataCommon_FileType = New System.Windows.Forms.CheckBox()
        Me.CheckBox_MetadataCommon_FileSize = New System.Windows.Forms.CheckBox()
        Me.CheckBox_MetadataCommon_OriginalCreatedDate = New System.Windows.Forms.CheckBox()
        Me.CheckBox_MetadataCommon_OriginalModifiedDate = New System.Windows.Forms.CheckBox()
        Me.CheckBox_MetadataCommon_OriginalDocumentHash = New System.Windows.Forms.CheckBox()
        Me.CheckBox_MetadataCommon_OriginalDocumentPath = New System.Windows.Forms.CheckBox()
        Me.CheckBox_MetadataCommon_PageNumber = New System.Windows.Forms.CheckBox()
        Me.CheckBox_MetadataCommon_PageCount = New System.Windows.Forms.CheckBox()
        Me.CheckBox_MetadataCommon_TextFileCreatedDate = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Options_TextFile = New System.Windows.Forms.GroupBox()
        Me.Button_TextFile_Default = New System.Windows.Forms.Button()
        Me.FlowLayoutPanel_TextOptions = New System.Windows.Forms.FlowLayoutPanel()
        Me.CheckBox_TextFile_IncludePageNumbers = New System.Windows.Forms.CheckBox()
        Me.CheckBox_TextFile_LineBreaksPerPage = New System.Windows.Forms.CheckBox()
        Me.Panel_LineBreaksPerPage = New System.Windows.Forms.Panel()
        Me.DomainUpDown_LineBreaksPerPage = New System.Windows.Forms.DomainUpDown()
        Me.CheckBox_TextFile_SplitFilesByPage = New System.Windows.Forms.CheckBox()
        Me.CheckBox_TextFile_RetainTableStructures = New System.Windows.Forms.CheckBox()
        Me.Panel_Delimiter = New System.Windows.Forms.Panel()
        Me.DomainUpDown_Delimiter = New System.Windows.Forms.DomainUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CheckBox_TextFile_ReformatTextBlocks = New System.Windows.Forms.CheckBox()
        Me.Panel_LineBreakPerSentences = New System.Windows.Forms.Panel()
        Me.DomainUpDown_LineBreakPerSentences = New System.Windows.Forms.DomainUpDown()
        Me.Label_TextFile_LineBreakPerSentences = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Button_Logging_ClearInAppLog = New System.Windows.Forms.Button()
        Me.Button_Logging_ViewLogFile = New System.Windows.Forms.Button()
        Me.Panel1_Logging_Output = New System.Windows.Forms.Panel()
        Me.RichTextBox_Logging_Output = New System.Windows.Forms.RichTextBox()
        Me.Button_ConvertAll = New System.Windows.Forms.Button()
        Me.Button_ConvertSelected = New System.Windows.Forms.Button()
        Me.CheckBox_Main_LoggingEnabled = New System.Windows.Forms.CheckBox()
        Me.Panel_Sources.SuspendLayout()
        Me.ToolStrip_Sources.SuspendLayout()
        Me.Panel_Parent_MenustripMain.SuspendLayout()
        Me.MenuStripMain.SuspendLayout()
        Me.GroupBox_Documents_Source.SuspendLayout()
        CType(Me.DataGridView_Documents_Sources, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel_Parent_ToolstripMain.SuspendLayout()
        Me.ToolStripMain.SuspendLayout()
        Me.Panel_Parent_Status.SuspendLayout()
        Me.Panel_StatusMessage.SuspendLayout()
        Me.GroupBox_Documents_DestinationText.SuspendLayout()
        Me.Panel_DestinationText_RadioButtonsFilename.SuspendLayout()
        Me.Panel_DestinationText_Filename.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel_DestinationText_RadioButtonsDirectory.SuspendLayout()
        Me.Panel_DestinationText_Directory.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.TabControlMain.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox_Documents_DestinationMetadata.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel_DestinationMetadata_RadioButtons.SuspendLayout()
        Me.Panel_DestinationMetadata_Directory.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel_DestinationMetadata_Checkboxes.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox_Options_MetadataCustom.SuspendLayout()
        Me.Panel_MetadataCustom_Toolstrip.SuspendLayout()
        Me.ToolStrip_MetadataCustom.SuspendLayout()
        CType(Me.DataGridView_Options_MetadataCustom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Options_MetadataCommon.SuspendLayout()
        Me.FlowLayoutPanel_MetadataCommonOptions.SuspendLayout()
        Me.GroupBox_Options_TextFile.SuspendLayout()
        Me.FlowLayoutPanel_TextOptions.SuspendLayout()
        Me.Panel_LineBreaksPerPage.SuspendLayout()
        Me.Panel_Delimiter.SuspendLayout()
        Me.Panel_LineBreakPerSentences.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.Panel1_Logging_Output.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel_Sources
        '
        Me.Panel_Sources.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_Sources.Controls.Add(Me.Label_Sources_DocCountValue)
        Me.Panel_Sources.Controls.Add(Me.ToolStrip_Sources)
        Me.Panel_Sources.Controls.Add(Me.Label_Sources_DocCount)
        Me.Panel_Sources.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel_Sources.Location = New System.Drawing.Point(11, 17)
        Me.Panel_Sources.Name = "Panel_Sources"
        Me.Panel_Sources.Size = New System.Drawing.Size(956, 25)
        Me.Panel_Sources.TabIndex = 40
        '
        'Label_Sources_DocCountValue
        '
        Me.Label_Sources_DocCountValue.AutoSize = True
        Me.Label_Sources_DocCountValue.Location = New System.Drawing.Point(110, 6)
        Me.Label_Sources_DocCountValue.Name = "Label_Sources_DocCountValue"
        Me.Label_Sources_DocCountValue.Size = New System.Drawing.Size(10, 12)
        Me.Label_Sources_DocCountValue.TabIndex = 43
        Me.Label_Sources_DocCountValue.Text = "0"
        '
        'ToolStrip_Sources
        '
        Me.ToolStrip_Sources.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip_Sources.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton_ManageSources, Me.ToolStrip_Sources_Button_Refresh, Me.ToolStrip_Sources_Button_DocInfo})
        Me.ToolStrip_Sources.Location = New System.Drawing.Point(-9, 0)
        Me.ToolStrip_Sources.Name = "ToolStrip_Sources"
        Me.ToolStrip_Sources.Size = New System.Drawing.Size(81, 25)
        Me.ToolStrip_Sources.TabIndex = 41
        Me.ToolStrip_Sources.Text = "ToolStrip1"
        '
        'ToolStripButton_ManageSources
        '
        Me.ToolStripButton_ManageSources.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton_ManageSources.Image = Global.DocStrip.My.Resources.Resources.icon_magnifying_glass
        Me.ToolStripButton_ManageSources.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton_ManageSources.Name = "ToolStripButton_ManageSources"
        Me.ToolStripButton_ManageSources.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton_ManageSources.Text = "Manage Sources"
        '
        'ToolStrip_Sources_Button_Refresh
        '
        Me.ToolStrip_Sources_Button_Refresh.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStrip_Sources_Button_Refresh.Image = Global.DocStrip.My.Resources.Resources.icon_refresh
        Me.ToolStrip_Sources_Button_Refresh.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStrip_Sources_Button_Refresh.Name = "ToolStrip_Sources_Button_Refresh"
        Me.ToolStrip_Sources_Button_Refresh.Size = New System.Drawing.Size(23, 22)
        Me.ToolStrip_Sources_Button_Refresh.Text = "Refresh / Import from Sources"
        '
        'ToolStrip_Sources_Button_DocInfo
        '
        Me.ToolStrip_Sources_Button_DocInfo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStrip_Sources_Button_DocInfo.Image = Global.DocStrip.My.Resources.Resources.icon_info
        Me.ToolStrip_Sources_Button_DocInfo.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStrip_Sources_Button_DocInfo.Name = "ToolStrip_Sources_Button_DocInfo"
        Me.ToolStrip_Sources_Button_DocInfo.Size = New System.Drawing.Size(23, 22)
        Me.ToolStrip_Sources_Button_DocInfo.Text = "Show Doc Info"
        '
        'Label_Sources_DocCount
        '
        Me.Label_Sources_DocCount.AutoSize = True
        Me.Label_Sources_DocCount.Location = New System.Drawing.Point(78, 6)
        Me.Label_Sources_DocCount.Name = "Label_Sources_DocCount"
        Me.Label_Sources_DocCount.Size = New System.Drawing.Size(33, 12)
        Me.Label_Sources_DocCount.TabIndex = 42
        Me.Label_Sources_DocCount.Text = "Count:"
        '
        'Panel_Parent_MenustripMain
        '
        Me.Panel_Parent_MenustripMain.BackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.Panel_Parent_MenustripMain.Controls.Add(Me.MenuStripMain)
        Me.Panel_Parent_MenustripMain.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel_Parent_MenustripMain.Location = New System.Drawing.Point(0, 0)
        Me.Panel_Parent_MenustripMain.Name = "Panel_Parent_MenustripMain"
        Me.Panel_Parent_MenustripMain.Size = New System.Drawing.Size(1022, 27)
        Me.Panel_Parent_MenustripMain.TabIndex = 1
        '
        'MenuStripMain
        '
        Me.MenuStripMain.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MenuStripMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStripMain.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripMain.Name = "MenuStripMain"
        Me.MenuStripMain.Size = New System.Drawing.Size(1022, 27)
        Me.MenuStripMain.TabIndex = 2
        Me.MenuStripMain.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.ForeColor = System.Drawing.Color.Black
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 23)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(93, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ResetApplicationToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 23)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'ResetApplicationToolStripMenuItem
        '
        Me.ResetApplicationToolStripMenuItem.Name = "ResetApplicationToolStripMenuItem"
        Me.ResetApplicationToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.ResetApplicationToolStripMenuItem.Text = "Reset Application"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 23)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'VToolStripMenuItem
        '
        Me.VToolStripMenuItem.Name = "VToolStripMenuItem"
        Me.VToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.VToolStripMenuItem.Text = "View Logs"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'GroupBox_Documents_Source
        '
        Me.GroupBox_Documents_Source.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Documents_Source.Controls.Add(Me.DataGridView_Documents_Sources)
        Me.GroupBox_Documents_Source.Controls.Add(Me.Panel_Sources)
        Me.GroupBox_Documents_Source.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Documents_Source.Location = New System.Drawing.Point(11, 9)
        Me.GroupBox_Documents_Source.Name = "GroupBox_Documents_Source"
        Me.GroupBox_Documents_Source.Size = New System.Drawing.Size(978, 257)
        Me.GroupBox_Documents_Source.TabIndex = 30
        Me.GroupBox_Documents_Source.TabStop = False
        Me.GroupBox_Documents_Source.Text = "Source Documents"
        '
        'DataGridView_Documents_Sources
        '
        Me.DataGridView_Documents_Sources.AllowUserToAddRows = False
        Me.DataGridView_Documents_Sources.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView_Documents_Sources.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView_Documents_Sources.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Source, Me.FileType})
        Me.DataGridView_Documents_Sources.Location = New System.Drawing.Point(11, 45)
        Me.DataGridView_Documents_Sources.Name = "DataGridView_Documents_Sources"
        Me.DataGridView_Documents_Sources.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView_Documents_Sources.Size = New System.Drawing.Size(956, 200)
        Me.DataGridView_Documents_Sources.TabIndex = 42
        '
        'Source
        '
        Me.Source.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Source.HeaderText = "Documents"
        Me.Source.Name = "Source"
        Me.Source.ReadOnly = True
        '
        'FileType
        '
        Me.FileType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.FileType.HeaderText = "File Type"
        Me.FileType.Name = "FileType"
        Me.FileType.ReadOnly = True
        Me.FileType.Width = 67
        '
        'Panel_Parent_ToolstripMain
        '
        Me.Panel_Parent_ToolstripMain.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel_Parent_ToolstripMain.Controls.Add(Me.ToolStripMain)
        Me.Panel_Parent_ToolstripMain.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel_Parent_ToolstripMain.Location = New System.Drawing.Point(0, 27)
        Me.Panel_Parent_ToolstripMain.Name = "Panel_Parent_ToolstripMain"
        Me.Panel_Parent_ToolstripMain.Size = New System.Drawing.Size(1022, 32)
        Me.Panel_Parent_ToolstripMain.TabIndex = 10
        Me.Panel_Parent_ToolstripMain.Visible = False
        '
        'ToolStripMain
        '
        Me.ToolStripMain.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ToolStripMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1})
        Me.ToolStripMain.Location = New System.Drawing.Point(0, 0)
        Me.ToolStripMain.Name = "ToolStripMain"
        Me.ToolStripMain.Size = New System.Drawing.Size(1022, 32)
        Me.ToolStripMain.TabIndex = 11
        Me.ToolStripMain.Text = "ToolStrip1"
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(23, 29)
        Me.ToolStripButton1.Text = "ToolStripButton1"
        '
        'Panel_Parent_Status
        '
        Me.Panel_Parent_Status.BackColor = System.Drawing.Color.LightGray
        Me.Panel_Parent_Status.Controls.Add(Me.Panel_StatusMessage)
        Me.Panel_Parent_Status.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel_Parent_Status.Location = New System.Drawing.Point(0, 628)
        Me.Panel_Parent_Status.Name = "Panel_Parent_Status"
        Me.Panel_Parent_Status.Size = New System.Drawing.Size(1022, 25)
        Me.Panel_Parent_Status.TabIndex = 200
        '
        'Panel_StatusMessage
        '
        Me.Panel_StatusMessage.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_StatusMessage.Controls.Add(Me.Label_StatusMessage)
        Me.Panel_StatusMessage.Controls.Add(Me.ProgressBar_Status)
        Me.Panel_StatusMessage.Location = New System.Drawing.Point(3, 3)
        Me.Panel_StatusMessage.Name = "Panel_StatusMessage"
        Me.Panel_StatusMessage.Size = New System.Drawing.Size(1014, 19)
        Me.Panel_StatusMessage.TabIndex = 210
        '
        'Label_StatusMessage
        '
        Me.Label_StatusMessage.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_StatusMessage.AutoSize = True
        Me.Label_StatusMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label_StatusMessage.Location = New System.Drawing.Point(107, 3)
        Me.Label_StatusMessage.Name = "Label_StatusMessage"
        Me.Label_StatusMessage.Size = New System.Drawing.Size(73, 12)
        Me.Label_StatusMessage.TabIndex = 212
        Me.Label_StatusMessage.Text = "Status Message"
        '
        'ProgressBar_Status
        '
        Me.ProgressBar_Status.Location = New System.Drawing.Point(5, 6)
        Me.ProgressBar_Status.Name = "ProgressBar_Status"
        Me.ProgressBar_Status.Size = New System.Drawing.Size(100, 8)
        Me.ProgressBar_Status.Step = 0
        Me.ProgressBar_Status.Style = System.Windows.Forms.ProgressBarStyle.Marquee
        Me.ProgressBar_Status.TabIndex = 211
        Me.ProgressBar_Status.Value = 100
        '
        'GroupBox_Documents_DestinationText
        '
        Me.GroupBox_Documents_DestinationText.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Documents_DestinationText.Controls.Add(Me.Button_DestinationText_Default)
        Me.GroupBox_Documents_DestinationText.Controls.Add(Me.Panel_DestinationText_RadioButtonsFilename)
        Me.GroupBox_Documents_DestinationText.Controls.Add(Me.Panel_DestinationText_Filename)
        Me.GroupBox_Documents_DestinationText.Controls.Add(Me.Panel_DestinationText_RadioButtonsDirectory)
        Me.GroupBox_Documents_DestinationText.Controls.Add(Me.Panel_DestinationText_Directory)
        Me.GroupBox_Documents_DestinationText.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Documents_DestinationText.Location = New System.Drawing.Point(11, 272)
        Me.GroupBox_Documents_DestinationText.Name = "GroupBox_Documents_DestinationText"
        Me.GroupBox_Documents_DestinationText.Size = New System.Drawing.Size(978, 103)
        Me.GroupBox_Documents_DestinationText.TabIndex = 50
        Me.GroupBox_Documents_DestinationText.TabStop = False
        Me.GroupBox_Documents_DestinationText.Text = "Destination - Plain Text"
        '
        'Button_DestinationText_Default
        '
        Me.Button_DestinationText_Default.Location = New System.Drawing.Point(8, 21)
        Me.Button_DestinationText_Default.Name = "Button_DestinationText_Default"
        Me.Button_DestinationText_Default.Size = New System.Drawing.Size(52, 22)
        Me.Button_DestinationText_Default.TabIndex = 125
        Me.Button_DestinationText_Default.Text = "Default"
        Me.Button_DestinationText_Default.UseVisualStyleBackColor = True
        '
        'Panel_DestinationText_RadioButtonsFilename
        '
        Me.Panel_DestinationText_RadioButtonsFilename.Controls.Add(Me.RadioButton_DestinationText_PrependFilename)
        Me.Panel_DestinationText_RadioButtonsFilename.Controls.Add(Me.RadioButton_DestinationText_CustomFilename)
        Me.Panel_DestinationText_RadioButtonsFilename.Controls.Add(Me.RadioButton_DestinationText_AppendFilename)
        Me.Panel_DestinationText_RadioButtonsFilename.Controls.Add(Me.RadioButton_DestinationText_SameOriginFile)
        Me.Panel_DestinationText_RadioButtonsFilename.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel_DestinationText_RadioButtonsFilename.Location = New System.Drawing.Point(6, 73)
        Me.Panel_DestinationText_RadioButtonsFilename.Name = "Panel_DestinationText_RadioButtonsFilename"
        Me.Panel_DestinationText_RadioButtonsFilename.Size = New System.Drawing.Size(304, 22)
        Me.Panel_DestinationText_RadioButtonsFilename.TabIndex = 58
        '
        'RadioButton_DestinationText_PrependFilename
        '
        Me.RadioButton_DestinationText_PrependFilename.AutoSize = True
        Me.RadioButton_DestinationText_PrependFilename.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton_DestinationText_PrependFilename.Location = New System.Drawing.Point(94, 3)
        Me.RadioButton_DestinationText_PrependFilename.Name = "RadioButton_DestinationText_PrependFilename"
        Me.RadioButton_DestinationText_PrependFilename.Size = New System.Drawing.Size(57, 16)
        Me.RadioButton_DestinationText_PrependFilename.TabIndex = 62
        Me.RadioButton_DestinationText_PrependFilename.TabStop = True
        Me.RadioButton_DestinationText_PrependFilename.Text = "Prepend"
        Me.RadioButton_DestinationText_PrependFilename.UseVisualStyleBackColor = False
        '
        'RadioButton_DestinationText_CustomFilename
        '
        Me.RadioButton_DestinationText_CustomFilename.AutoSize = True
        Me.RadioButton_DestinationText_CustomFilename.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton_DestinationText_CustomFilename.Location = New System.Drawing.Point(218, 3)
        Me.RadioButton_DestinationText_CustomFilename.Name = "RadioButton_DestinationText_CustomFilename"
        Me.RadioButton_DestinationText_CustomFilename.Size = New System.Drawing.Size(83, 16)
        Me.RadioButton_DestinationText_CustomFilename.TabIndex = 61
        Me.RadioButton_DestinationText_CustomFilename.TabStop = True
        Me.RadioButton_DestinationText_CustomFilename.Text = "Custom Name"
        Me.RadioButton_DestinationText_CustomFilename.UseVisualStyleBackColor = False
        '
        'RadioButton_DestinationText_AppendFilename
        '
        Me.RadioButton_DestinationText_AppendFilename.AutoSize = True
        Me.RadioButton_DestinationText_AppendFilename.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton_DestinationText_AppendFilename.Location = New System.Drawing.Point(157, 3)
        Me.RadioButton_DestinationText_AppendFilename.Name = "RadioButton_DestinationText_AppendFilename"
        Me.RadioButton_DestinationText_AppendFilename.Size = New System.Drawing.Size(55, 16)
        Me.RadioButton_DestinationText_AppendFilename.TabIndex = 60
        Me.RadioButton_DestinationText_AppendFilename.TabStop = True
        Me.RadioButton_DestinationText_AppendFilename.Text = "Append"
        Me.RadioButton_DestinationText_AppendFilename.UseVisualStyleBackColor = False
        '
        'RadioButton_DestinationText_SameOriginFile
        '
        Me.RadioButton_DestinationText_SameOriginFile.AutoSize = True
        Me.RadioButton_DestinationText_SameOriginFile.Location = New System.Drawing.Point(3, 3)
        Me.RadioButton_DestinationText_SameOriginFile.Name = "RadioButton_DestinationText_SameOriginFile"
        Me.RadioButton_DestinationText_SameOriginFile.Size = New System.Drawing.Size(85, 16)
        Me.RadioButton_DestinationText_SameOriginFile.TabIndex = 59
        Me.RadioButton_DestinationText_SameOriginFile.TabStop = True
        Me.RadioButton_DestinationText_SameOriginFile.Text = "Same as Origin"
        Me.RadioButton_DestinationText_SameOriginFile.UseVisualStyleBackColor = True
        '
        'Panel_DestinationText_Filename
        '
        Me.Panel_DestinationText_Filename.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_DestinationText_Filename.Controls.Add(Me.Label_DestinationText_Filename)
        Me.Panel_DestinationText_Filename.Controls.Add(Me.Panel7)
        Me.Panel_DestinationText_Filename.Enabled = False
        Me.Panel_DestinationText_Filename.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel_DestinationText_Filename.Location = New System.Drawing.Point(316, 73)
        Me.Panel_DestinationText_Filename.Name = "Panel_DestinationText_Filename"
        Me.Panel_DestinationText_Filename.Size = New System.Drawing.Size(584, 22)
        Me.Panel_DestinationText_Filename.TabIndex = 62
        '
        'Label_DestinationText_Filename
        '
        Me.Label_DestinationText_Filename.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_DestinationText_Filename.AutoSize = True
        Me.Label_DestinationText_Filename.Location = New System.Drawing.Point(4, 5)
        Me.Label_DestinationText_Filename.Name = "Label_DestinationText_Filename"
        Me.Label_DestinationText_Filename.Size = New System.Drawing.Size(50, 12)
        Me.Label_DestinationText_Filename.TabIndex = 63
        Me.Label_DestinationText_Filename.Text = "File Name:"
        '
        'Panel7
        '
        Me.Panel7.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel7.Controls.Add(Me.TextBox_DestinationText_Filename)
        Me.Panel7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel7.Location = New System.Drawing.Point(54, 3)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(527, 16)
        Me.Panel7.TabIndex = 2
        '
        'TextBox_DestinationText_Filename
        '
        Me.TextBox_DestinationText_Filename.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_DestinationText_Filename.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_DestinationText_Filename.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_DestinationText_Filename.Multiline = True
        Me.TextBox_DestinationText_Filename.Name = "TextBox_DestinationText_Filename"
        Me.TextBox_DestinationText_Filename.Size = New System.Drawing.Size(525, 14)
        Me.TextBox_DestinationText_Filename.TabIndex = 64
        '
        'Panel_DestinationText_RadioButtonsDirectory
        '
        Me.Panel_DestinationText_RadioButtonsDirectory.Controls.Add(Me.RadioButton_DestinationText_Custom)
        Me.Panel_DestinationText_RadioButtonsDirectory.Controls.Add(Me.RadioButton_DestinationText_SameOriginFolder)
        Me.Panel_DestinationText_RadioButtonsDirectory.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel_DestinationText_RadioButtonsDirectory.Location = New System.Drawing.Point(6, 48)
        Me.Panel_DestinationText_RadioButtonsDirectory.Name = "Panel_DestinationText_RadioButtonsDirectory"
        Me.Panel_DestinationText_RadioButtonsDirectory.Size = New System.Drawing.Size(304, 22)
        Me.Panel_DestinationText_RadioButtonsDirectory.TabIndex = 51
        '
        'RadioButton_DestinationText_Custom
        '
        Me.RadioButton_DestinationText_Custom.AutoSize = True
        Me.RadioButton_DestinationText_Custom.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton_DestinationText_Custom.Location = New System.Drawing.Point(94, 3)
        Me.RadioButton_DestinationText_Custom.Name = "RadioButton_DestinationText_Custom"
        Me.RadioButton_DestinationText_Custom.Size = New System.Drawing.Size(56, 16)
        Me.RadioButton_DestinationText_Custom.TabIndex = 53
        Me.RadioButton_DestinationText_Custom.TabStop = True
        Me.RadioButton_DestinationText_Custom.Text = "Custom"
        Me.RadioButton_DestinationText_Custom.UseVisualStyleBackColor = False
        '
        'RadioButton_DestinationText_SameOriginFolder
        '
        Me.RadioButton_DestinationText_SameOriginFolder.AutoSize = True
        Me.RadioButton_DestinationText_SameOriginFolder.Location = New System.Drawing.Point(3, 3)
        Me.RadioButton_DestinationText_SameOriginFolder.Name = "RadioButton_DestinationText_SameOriginFolder"
        Me.RadioButton_DestinationText_SameOriginFolder.Size = New System.Drawing.Size(85, 16)
        Me.RadioButton_DestinationText_SameOriginFolder.TabIndex = 52
        Me.RadioButton_DestinationText_SameOriginFolder.TabStop = True
        Me.RadioButton_DestinationText_SameOriginFolder.Text = "Same as Origin"
        Me.RadioButton_DestinationText_SameOriginFolder.UseVisualStyleBackColor = True
        '
        'Panel_DestinationText_Directory
        '
        Me.Panel_DestinationText_Directory.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_DestinationText_Directory.Controls.Add(Me.Button_DestinationText_Browse)
        Me.Panel_DestinationText_Directory.Controls.Add(Me.Label_DestinationText_Directory)
        Me.Panel_DestinationText_Directory.Controls.Add(Me.Panel12)
        Me.Panel_DestinationText_Directory.Enabled = False
        Me.Panel_DestinationText_Directory.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel_DestinationText_Directory.Location = New System.Drawing.Point(316, 48)
        Me.Panel_DestinationText_Directory.Name = "Panel_DestinationText_Directory"
        Me.Panel_DestinationText_Directory.Size = New System.Drawing.Size(651, 22)
        Me.Panel_DestinationText_Directory.TabIndex = 54
        '
        'Button_DestinationText_Browse
        '
        Me.Button_DestinationText_Browse.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_DestinationText_Browse.Location = New System.Drawing.Point(594, 0)
        Me.Button_DestinationText_Browse.Name = "Button_DestinationText_Browse"
        Me.Button_DestinationText_Browse.Size = New System.Drawing.Size(57, 22)
        Me.Button_DestinationText_Browse.TabIndex = 57
        Me.Button_DestinationText_Browse.Text = "Browse"
        Me.Button_DestinationText_Browse.UseVisualStyleBackColor = True
        '
        'Label_DestinationText_Directory
        '
        Me.Label_DestinationText_Directory.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_DestinationText_Directory.AutoSize = True
        Me.Label_DestinationText_Directory.Location = New System.Drawing.Point(4, 5)
        Me.Label_DestinationText_Directory.Name = "Label_DestinationText_Directory"
        Me.Label_DestinationText_Directory.Size = New System.Drawing.Size(46, 12)
        Me.Label_DestinationText_Directory.TabIndex = 55
        Me.Label_DestinationText_Directory.Text = "Directory:"
        '
        'Panel12
        '
        Me.Panel12.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel12.Controls.Add(Me.TextBox_DestinationText_Directory)
        Me.Panel12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel12.Location = New System.Drawing.Point(54, 3)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(527, 16)
        Me.Panel12.TabIndex = 2
        '
        'TextBox_DestinationText_Directory
        '
        Me.TextBox_DestinationText_Directory.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_DestinationText_Directory.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_DestinationText_Directory.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_DestinationText_Directory.Multiline = True
        Me.TextBox_DestinationText_Directory.Name = "TextBox_DestinationText_Directory"
        Me.TextBox_DestinationText_Directory.Size = New System.Drawing.Size(525, 14)
        Me.TextBox_DestinationText_Directory.TabIndex = 56
        '
        'TabControlMain
        '
        Me.TabControlMain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControlMain.Controls.Add(Me.TabPage1)
        Me.TabControlMain.Controls.Add(Me.TabPage2)
        Me.TabControlMain.Controls.Add(Me.TabPage3)
        Me.TabControlMain.Location = New System.Drawing.Point(8, 65)
        Me.TabControlMain.Name = "TabControlMain"
        Me.TabControlMain.SelectedIndex = 0
        Me.TabControlMain.Size = New System.Drawing.Size(1009, 528)
        Me.TabControlMain.TabIndex = 20
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.GroupBox_Documents_DestinationMetadata)
        Me.TabPage1.Controls.Add(Me.GroupBox_Documents_Source)
        Me.TabPage1.Controls.Add(Me.GroupBox_Documents_DestinationText)
        Me.TabPage1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1001, 502)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Documents"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'GroupBox_Documents_DestinationMetadata
        '
        Me.GroupBox_Documents_DestinationMetadata.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Documents_DestinationMetadata.Controls.Add(Me.Button_DestinationMetadata_Default)
        Me.GroupBox_Documents_DestinationMetadata.Controls.Add(Me.Panel1)
        Me.GroupBox_Documents_DestinationMetadata.Controls.Add(Me.Panel_DestinationMetadata_Checkboxes)
        Me.GroupBox_Documents_DestinationMetadata.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Documents_DestinationMetadata.Location = New System.Drawing.Point(11, 381)
        Me.GroupBox_Documents_DestinationMetadata.Name = "GroupBox_Documents_DestinationMetadata"
        Me.GroupBox_Documents_DestinationMetadata.Size = New System.Drawing.Size(978, 108)
        Me.GroupBox_Documents_DestinationMetadata.TabIndex = 70
        Me.GroupBox_Documents_DestinationMetadata.TabStop = False
        Me.GroupBox_Documents_DestinationMetadata.Text = "Destination - Metadata"
        '
        'Button_DestinationMetadata_Default
        '
        Me.Button_DestinationMetadata_Default.Location = New System.Drawing.Point(8, 19)
        Me.Button_DestinationMetadata_Default.Name = "Button_DestinationMetadata_Default"
        Me.Button_DestinationMetadata_Default.Size = New System.Drawing.Size(52, 22)
        Me.Button_DestinationMetadata_Default.TabIndex = 126
        Me.Button_DestinationMetadata_Default.Text = "Default"
        Me.Button_DestinationMetadata_Default.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.Panel_DestinationMetadata_RadioButtons)
        Me.Panel1.Controls.Add(Me.Panel_DestinationMetadata_Directory)
        Me.Panel1.Location = New System.Drawing.Point(3, 72)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(971, 29)
        Me.Panel1.TabIndex = 78
        '
        'Panel_DestinationMetadata_RadioButtons
        '
        Me.Panel_DestinationMetadata_RadioButtons.Controls.Add(Me.RadioButton_DestinationMetadata_Custom)
        Me.Panel_DestinationMetadata_RadioButtons.Controls.Add(Me.RadioButton_DestinationMetadata_SameAsPlainText)
        Me.Panel_DestinationMetadata_RadioButtons.Controls.Add(Me.RadioButton_DestinationMetadata_SameOriginFolder)
        Me.Panel_DestinationMetadata_RadioButtons.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel_DestinationMetadata_RadioButtons.Location = New System.Drawing.Point(3, 3)
        Me.Panel_DestinationMetadata_RadioButtons.Name = "Panel_DestinationMetadata_RadioButtons"
        Me.Panel_DestinationMetadata_RadioButtons.Size = New System.Drawing.Size(304, 22)
        Me.Panel_DestinationMetadata_RadioButtons.TabIndex = 73
        '
        'RadioButton_DestinationMetadata_Custom
        '
        Me.RadioButton_DestinationMetadata_Custom.AutoSize = True
        Me.RadioButton_DestinationMetadata_Custom.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton_DestinationMetadata_Custom.Location = New System.Drawing.Point(110, 3)
        Me.RadioButton_DestinationMetadata_Custom.Name = "RadioButton_DestinationMetadata_Custom"
        Me.RadioButton_DestinationMetadata_Custom.Size = New System.Drawing.Size(56, 16)
        Me.RadioButton_DestinationMetadata_Custom.TabIndex = 76
        Me.RadioButton_DestinationMetadata_Custom.TabStop = True
        Me.RadioButton_DestinationMetadata_Custom.Text = "Custom"
        Me.RadioButton_DestinationMetadata_Custom.UseVisualStyleBackColor = False
        '
        'RadioButton_DestinationMetadata_SameAsPlainText
        '
        Me.RadioButton_DestinationMetadata_SameAsPlainText.AutoSize = True
        Me.RadioButton_DestinationMetadata_SameAsPlainText.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton_DestinationMetadata_SameAsPlainText.Location = New System.Drawing.Point(172, 3)
        Me.RadioButton_DestinationMetadata_SameAsPlainText.Name = "RadioButton_DestinationMetadata_SameAsPlainText"
        Me.RadioButton_DestinationMetadata_SameAsPlainText.Size = New System.Drawing.Size(101, 16)
        Me.RadioButton_DestinationMetadata_SameAsPlainText.TabIndex = 75
        Me.RadioButton_DestinationMetadata_SameAsPlainText.TabStop = True
        Me.RadioButton_DestinationMetadata_SameAsPlainText.Text = "Same as Plain Text"
        Me.RadioButton_DestinationMetadata_SameAsPlainText.UseVisualStyleBackColor = False
        Me.RadioButton_DestinationMetadata_SameAsPlainText.Visible = False
        '
        'RadioButton_DestinationMetadata_SameOriginFolder
        '
        Me.RadioButton_DestinationMetadata_SameOriginFolder.AutoSize = True
        Me.RadioButton_DestinationMetadata_SameOriginFolder.Location = New System.Drawing.Point(3, 3)
        Me.RadioButton_DestinationMetadata_SameOriginFolder.Name = "RadioButton_DestinationMetadata_SameOriginFolder"
        Me.RadioButton_DestinationMetadata_SameOriginFolder.Size = New System.Drawing.Size(101, 16)
        Me.RadioButton_DestinationMetadata_SameOriginFolder.TabIndex = 74
        Me.RadioButton_DestinationMetadata_SameOriginFolder.TabStop = True
        Me.RadioButton_DestinationMetadata_SameOriginFolder.Text = "Same as Plain Text"
        Me.RadioButton_DestinationMetadata_SameOriginFolder.UseVisualStyleBackColor = True
        '
        'Panel_DestinationMetadata_Directory
        '
        Me.Panel_DestinationMetadata_Directory.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_DestinationMetadata_Directory.Controls.Add(Me.Button_DestinationMetadata_Browse)
        Me.Panel_DestinationMetadata_Directory.Controls.Add(Me.Label_DestinationMetadata_Directory)
        Me.Panel_DestinationMetadata_Directory.Controls.Add(Me.Panel10)
        Me.Panel_DestinationMetadata_Directory.Enabled = False
        Me.Panel_DestinationMetadata_Directory.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel_DestinationMetadata_Directory.Location = New System.Drawing.Point(313, 3)
        Me.Panel_DestinationMetadata_Directory.Name = "Panel_DestinationMetadata_Directory"
        Me.Panel_DestinationMetadata_Directory.Size = New System.Drawing.Size(651, 22)
        Me.Panel_DestinationMetadata_Directory.TabIndex = 77
        '
        'Button_DestinationMetadata_Browse
        '
        Me.Button_DestinationMetadata_Browse.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_DestinationMetadata_Browse.Location = New System.Drawing.Point(594, 0)
        Me.Button_DestinationMetadata_Browse.Name = "Button_DestinationMetadata_Browse"
        Me.Button_DestinationMetadata_Browse.Size = New System.Drawing.Size(57, 22)
        Me.Button_DestinationMetadata_Browse.TabIndex = 80
        Me.Button_DestinationMetadata_Browse.Text = "Browse"
        Me.Button_DestinationMetadata_Browse.UseVisualStyleBackColor = True
        '
        'Label_DestinationMetadata_Directory
        '
        Me.Label_DestinationMetadata_Directory.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_DestinationMetadata_Directory.AutoSize = True
        Me.Label_DestinationMetadata_Directory.Location = New System.Drawing.Point(4, 5)
        Me.Label_DestinationMetadata_Directory.Name = "Label_DestinationMetadata_Directory"
        Me.Label_DestinationMetadata_Directory.Size = New System.Drawing.Size(46, 12)
        Me.Label_DestinationMetadata_Directory.TabIndex = 78
        Me.Label_DestinationMetadata_Directory.Text = "Directory:"
        '
        'Panel10
        '
        Me.Panel10.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel10.Controls.Add(Me.TextBox_DestinationMetadata_Directory)
        Me.Panel10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel10.Location = New System.Drawing.Point(54, 3)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(527, 16)
        Me.Panel10.TabIndex = 2
        '
        'TextBox_DestinationMetadata_Directory
        '
        Me.TextBox_DestinationMetadata_Directory.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_DestinationMetadata_Directory.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_DestinationMetadata_Directory.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_DestinationMetadata_Directory.Multiline = True
        Me.TextBox_DestinationMetadata_Directory.Name = "TextBox_DestinationMetadata_Directory"
        Me.TextBox_DestinationMetadata_Directory.Size = New System.Drawing.Size(525, 14)
        Me.TextBox_DestinationMetadata_Directory.TabIndex = 79
        '
        'Panel_DestinationMetadata_Checkboxes
        '
        Me.Panel_DestinationMetadata_Checkboxes.Controls.Add(Me.CheckBox_DestinationMetadata_GenerateMetadata)
        Me.Panel_DestinationMetadata_Checkboxes.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel_DestinationMetadata_Checkboxes.Location = New System.Drawing.Point(6, 47)
        Me.Panel_DestinationMetadata_Checkboxes.Name = "Panel_DestinationMetadata_Checkboxes"
        Me.Panel_DestinationMetadata_Checkboxes.Size = New System.Drawing.Size(304, 22)
        Me.Panel_DestinationMetadata_Checkboxes.TabIndex = 71
        '
        'CheckBox_DestinationMetadata_GenerateMetadata
        '
        Me.CheckBox_DestinationMetadata_GenerateMetadata.AutoSize = True
        Me.CheckBox_DestinationMetadata_GenerateMetadata.Location = New System.Drawing.Point(3, 3)
        Me.CheckBox_DestinationMetadata_GenerateMetadata.Name = "CheckBox_DestinationMetadata_GenerateMetadata"
        Me.CheckBox_DestinationMetadata_GenerateMetadata.Size = New System.Drawing.Size(104, 16)
        Me.CheckBox_DestinationMetadata_GenerateMetadata.TabIndex = 72
        Me.CheckBox_DestinationMetadata_GenerateMetadata.Text = "Generate Metadata"
        Me.CheckBox_DestinationMetadata_GenerateMetadata.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.GroupBox_Options_MetadataCustom)
        Me.TabPage2.Controls.Add(Me.GroupBox_Options_MetadataCommon)
        Me.TabPage2.Controls.Add(Me.GroupBox_Options_TextFile)
        Me.TabPage2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1001, 502)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Options"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'GroupBox_Options_MetadataCustom
        '
        Me.GroupBox_Options_MetadataCustom.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Options_MetadataCustom.Controls.Add(Me.Panel_MetadataCustom_Toolstrip)
        Me.GroupBox_Options_MetadataCustom.Controls.Add(Me.DataGridView_Options_MetadataCustom)
        Me.GroupBox_Options_MetadataCustom.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Options_MetadataCustom.Location = New System.Drawing.Point(11, 280)
        Me.GroupBox_Options_MetadataCustom.Name = "GroupBox_Options_MetadataCustom"
        Me.GroupBox_Options_MetadataCustom.Size = New System.Drawing.Size(979, 211)
        Me.GroupBox_Options_MetadataCustom.TabIndex = 140
        Me.GroupBox_Options_MetadataCustom.TabStop = False
        Me.GroupBox_Options_MetadataCustom.Text = "Include Metadata - Custom"
        '
        'Panel_MetadataCustom_Toolstrip
        '
        Me.Panel_MetadataCustom_Toolstrip.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_MetadataCustom_Toolstrip.Controls.Add(Me.ToolStrip_MetadataCustom)
        Me.Panel_MetadataCustom_Toolstrip.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel_MetadataCustom_Toolstrip.Location = New System.Drawing.Point(12, 18)
        Me.Panel_MetadataCustom_Toolstrip.Name = "Panel_MetadataCustom_Toolstrip"
        Me.Panel_MetadataCustom_Toolstrip.Size = New System.Drawing.Size(955, 25)
        Me.Panel_MetadataCustom_Toolstrip.TabIndex = 150
        '
        'ToolStrip_MetadataCustom
        '
        Me.ToolStrip_MetadataCustom.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip_MetadataCustom.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton6, Me.ToolStripDropDownButton2, Me.ToolStrip_MetadataCustom_Button_SelectAll, Me.ToolStrip_MetadataCustom_Button_DeleteSelected})
        Me.ToolStrip_MetadataCustom.Location = New System.Drawing.Point(-9, 0)
        Me.ToolStrip_MetadataCustom.Name = "ToolStrip_MetadataCustom"
        Me.ToolStrip_MetadataCustom.Size = New System.Drawing.Size(58, 25)
        Me.ToolStrip_MetadataCustom.TabIndex = 151
        Me.ToolStrip_MetadataCustom.Text = "ToolStrip2"
        '
        'ToolStripButton6
        '
        Me.ToolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton6.Image = CType(resources.GetObject("ToolStripButton6.Image"), System.Drawing.Image)
        Me.ToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton6.Name = "ToolStripButton6"
        Me.ToolStripButton6.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton6.Text = "Add Key/Value Pair"
        Me.ToolStripButton6.Visible = False
        '
        'ToolStripDropDownButton2
        '
        Me.ToolStripDropDownButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripDropDownButton2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ByKeyToolStripMenuItem, Me.ByValueToolStripMenuItem})
        Me.ToolStripDropDownButton2.Image = CType(resources.GetObject("ToolStripDropDownButton2.Image"), System.Drawing.Image)
        Me.ToolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripDropDownButton2.Name = "ToolStripDropDownButton2"
        Me.ToolStripDropDownButton2.Size = New System.Drawing.Size(29, 22)
        Me.ToolStripDropDownButton2.Text = "Sort"
        Me.ToolStripDropDownButton2.Visible = False
        '
        'ByKeyToolStripMenuItem
        '
        Me.ByKeyToolStripMenuItem.Name = "ByKeyToolStripMenuItem"
        Me.ByKeyToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.ByKeyToolStripMenuItem.Text = "Sort by Key"
        '
        'ByValueToolStripMenuItem
        '
        Me.ByValueToolStripMenuItem.Name = "ByValueToolStripMenuItem"
        Me.ByValueToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.ByValueToolStripMenuItem.Text = "Sort by Value"
        '
        'ToolStrip_MetadataCustom_Button_SelectAll
        '
        Me.ToolStrip_MetadataCustom_Button_SelectAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStrip_MetadataCustom_Button_SelectAll.Image = Global.DocStrip.My.Resources.Resources.icon_selectAllDeselectAll
        Me.ToolStrip_MetadataCustom_Button_SelectAll.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStrip_MetadataCustom_Button_SelectAll.Name = "ToolStrip_MetadataCustom_Button_SelectAll"
        Me.ToolStrip_MetadataCustom_Button_SelectAll.Size = New System.Drawing.Size(23, 22)
        Me.ToolStrip_MetadataCustom_Button_SelectAll.Text = "Select All"
        '
        'ToolStrip_MetadataCustom_Button_DeleteSelected
        '
        Me.ToolStrip_MetadataCustom_Button_DeleteSelected.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStrip_MetadataCustom_Button_DeleteSelected.Image = Global.DocStrip.My.Resources.Resources.icon_delete
        Me.ToolStrip_MetadataCustom_Button_DeleteSelected.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStrip_MetadataCustom_Button_DeleteSelected.Name = "ToolStrip_MetadataCustom_Button_DeleteSelected"
        Me.ToolStrip_MetadataCustom_Button_DeleteSelected.Size = New System.Drawing.Size(23, 22)
        Me.ToolStrip_MetadataCustom_Button_DeleteSelected.Text = "Delete Selected"
        '
        'DataGridView_Options_MetadataCustom
        '
        Me.DataGridView_Options_MetadataCustom.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView_Options_MetadataCustom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView_Options_MetadataCustom.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Key, Me.Value})
        Me.DataGridView_Options_MetadataCustom.Location = New System.Drawing.Point(12, 46)
        Me.DataGridView_Options_MetadataCustom.Name = "DataGridView_Options_MetadataCustom"
        Me.DataGridView_Options_MetadataCustom.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView_Options_MetadataCustom.Size = New System.Drawing.Size(955, 152)
        Me.DataGridView_Options_MetadataCustom.TabIndex = 152
        '
        'Key
        '
        Me.Key.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Key.HeaderText = "Key"
        Me.Key.Name = "Key"
        Me.Key.Width = 46
        '
        'Value
        '
        Me.Value.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Value.HeaderText = "Value"
        Me.Value.Name = "Value"
        '
        'GroupBox_Options_MetadataCommon
        '
        Me.GroupBox_Options_MetadataCommon.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Options_MetadataCommon.Controls.Add(Me.Button_MetadataCommon_Default)
        Me.GroupBox_Options_MetadataCommon.Controls.Add(Me.Button_MetadataCommon_None)
        Me.GroupBox_Options_MetadataCommon.Controls.Add(Me.Button_MetadataCommon_SelectAll)
        Me.GroupBox_Options_MetadataCommon.Controls.Add(Me.FlowLayoutPanel_MetadataCommonOptions)
        Me.GroupBox_Options_MetadataCommon.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Options_MetadataCommon.Location = New System.Drawing.Point(11, 146)
        Me.GroupBox_Options_MetadataCommon.Name = "GroupBox_Options_MetadataCommon"
        Me.GroupBox_Options_MetadataCommon.Size = New System.Drawing.Size(979, 126)
        Me.GroupBox_Options_MetadataCommon.TabIndex = 120
        Me.GroupBox_Options_MetadataCommon.TabStop = False
        Me.GroupBox_Options_MetadataCommon.Text = "Include Metadata - Common"
        '
        'Button_MetadataCommon_Default
        '
        Me.Button_MetadataCommon_Default.Location = New System.Drawing.Point(112, 25)
        Me.Button_MetadataCommon_Default.Name = "Button_MetadataCommon_Default"
        Me.Button_MetadataCommon_Default.Size = New System.Drawing.Size(52, 22)
        Me.Button_MetadataCommon_Default.TabIndex = 123
        Me.Button_MetadataCommon_Default.Text = "Default"
        Me.Button_MetadataCommon_Default.UseVisualStyleBackColor = True
        '
        'Button_MetadataCommon_None
        '
        Me.Button_MetadataCommon_None.Location = New System.Drawing.Point(69, 25)
        Me.Button_MetadataCommon_None.Name = "Button_MetadataCommon_None"
        Me.Button_MetadataCommon_None.Size = New System.Drawing.Size(42, 22)
        Me.Button_MetadataCommon_None.TabIndex = 122
        Me.Button_MetadataCommon_None.Text = "None"
        Me.Button_MetadataCommon_None.UseVisualStyleBackColor = True
        '
        'Button_MetadataCommon_SelectAll
        '
        Me.Button_MetadataCommon_SelectAll.Location = New System.Drawing.Point(11, 25)
        Me.Button_MetadataCommon_SelectAll.Name = "Button_MetadataCommon_SelectAll"
        Me.Button_MetadataCommon_SelectAll.Size = New System.Drawing.Size(57, 22)
        Me.Button_MetadataCommon_SelectAll.TabIndex = 121
        Me.Button_MetadataCommon_SelectAll.Text = "Select All"
        Me.Button_MetadataCommon_SelectAll.UseVisualStyleBackColor = True
        '
        'FlowLayoutPanel_MetadataCommonOptions
        '
        Me.FlowLayoutPanel_MetadataCommonOptions.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel_MetadataCommonOptions.Controls.Add(Me.CheckBox_MetadataCommon_Filename)
        Me.FlowLayoutPanel_MetadataCommonOptions.Controls.Add(Me.CheckBox_MetadataCommon_FileType)
        Me.FlowLayoutPanel_MetadataCommonOptions.Controls.Add(Me.CheckBox_MetadataCommon_FileSize)
        Me.FlowLayoutPanel_MetadataCommonOptions.Controls.Add(Me.CheckBox_MetadataCommon_OriginalCreatedDate)
        Me.FlowLayoutPanel_MetadataCommonOptions.Controls.Add(Me.CheckBox_MetadataCommon_OriginalModifiedDate)
        Me.FlowLayoutPanel_MetadataCommonOptions.Controls.Add(Me.CheckBox_MetadataCommon_OriginalDocumentHash)
        Me.FlowLayoutPanel_MetadataCommonOptions.Controls.Add(Me.CheckBox_MetadataCommon_OriginalDocumentPath)
        Me.FlowLayoutPanel_MetadataCommonOptions.Controls.Add(Me.CheckBox_MetadataCommon_PageNumber)
        Me.FlowLayoutPanel_MetadataCommonOptions.Controls.Add(Me.CheckBox_MetadataCommon_PageCount)
        Me.FlowLayoutPanel_MetadataCommonOptions.Controls.Add(Me.CheckBox_MetadataCommon_TextFileCreatedDate)
        Me.FlowLayoutPanel_MetadataCommonOptions.Location = New System.Drawing.Point(11, 56)
        Me.FlowLayoutPanel_MetadataCommonOptions.Name = "FlowLayoutPanel_MetadataCommonOptions"
        Me.FlowLayoutPanel_MetadataCommonOptions.Size = New System.Drawing.Size(959, 60)
        Me.FlowLayoutPanel_MetadataCommonOptions.TabIndex = 124
        '
        'CheckBox_MetadataCommon_Filename
        '
        Me.CheckBox_MetadataCommon_Filename.AutoSize = True
        Me.CheckBox_MetadataCommon_Filename.Location = New System.Drawing.Point(3, 3)
        Me.CheckBox_MetadataCommon_Filename.Name = "CheckBox_MetadataCommon_Filename"
        Me.CheckBox_MetadataCommon_Filename.Size = New System.Drawing.Size(66, 16)
        Me.CheckBox_MetadataCommon_Filename.TabIndex = 125
        Me.CheckBox_MetadataCommon_Filename.Text = "File Name"
        Me.CheckBox_MetadataCommon_Filename.UseVisualStyleBackColor = True
        '
        'CheckBox_MetadataCommon_FileType
        '
        Me.CheckBox_MetadataCommon_FileType.AutoSize = True
        Me.CheckBox_MetadataCommon_FileType.Location = New System.Drawing.Point(75, 3)
        Me.CheckBox_MetadataCommon_FileType.Name = "CheckBox_MetadataCommon_FileType"
        Me.CheckBox_MetadataCommon_FileType.Size = New System.Drawing.Size(61, 16)
        Me.CheckBox_MetadataCommon_FileType.TabIndex = 126
        Me.CheckBox_MetadataCommon_FileType.Text = "File Type"
        Me.CheckBox_MetadataCommon_FileType.UseVisualStyleBackColor = True
        '
        'CheckBox_MetadataCommon_FileSize
        '
        Me.CheckBox_MetadataCommon_FileSize.AutoSize = True
        Me.CheckBox_MetadataCommon_FileSize.Location = New System.Drawing.Point(142, 3)
        Me.CheckBox_MetadataCommon_FileSize.Name = "CheckBox_MetadataCommon_FileSize"
        Me.CheckBox_MetadataCommon_FileSize.Size = New System.Drawing.Size(85, 16)
        Me.CheckBox_MetadataCommon_FileSize.TabIndex = 127
        Me.CheckBox_MetadataCommon_FileSize.Text = "File Size Bytes"
        Me.CheckBox_MetadataCommon_FileSize.UseVisualStyleBackColor = True
        '
        'CheckBox_MetadataCommon_OriginalCreatedDate
        '
        Me.CheckBox_MetadataCommon_OriginalCreatedDate.AutoSize = True
        Me.CheckBox_MetadataCommon_OriginalCreatedDate.Location = New System.Drawing.Point(233, 3)
        Me.CheckBox_MetadataCommon_OriginalCreatedDate.Name = "CheckBox_MetadataCommon_OriginalCreatedDate"
        Me.CheckBox_MetadataCommon_OriginalCreatedDate.Size = New System.Drawing.Size(112, 16)
        Me.CheckBox_MetadataCommon_OriginalCreatedDate.TabIndex = 128
        Me.CheckBox_MetadataCommon_OriginalCreatedDate.Text = "Original Created Date"
        Me.CheckBox_MetadataCommon_OriginalCreatedDate.UseVisualStyleBackColor = True
        '
        'CheckBox_MetadataCommon_OriginalModifiedDate
        '
        Me.CheckBox_MetadataCommon_OriginalModifiedDate.AutoSize = True
        Me.CheckBox_MetadataCommon_OriginalModifiedDate.Location = New System.Drawing.Point(351, 3)
        Me.CheckBox_MetadataCommon_OriginalModifiedDate.Name = "CheckBox_MetadataCommon_OriginalModifiedDate"
        Me.CheckBox_MetadataCommon_OriginalModifiedDate.Size = New System.Drawing.Size(115, 16)
        Me.CheckBox_MetadataCommon_OriginalModifiedDate.TabIndex = 133
        Me.CheckBox_MetadataCommon_OriginalModifiedDate.Text = "Original Modified Date"
        Me.CheckBox_MetadataCommon_OriginalModifiedDate.UseVisualStyleBackColor = True
        '
        'CheckBox_MetadataCommon_OriginalDocumentHash
        '
        Me.CheckBox_MetadataCommon_OriginalDocumentHash.AutoSize = True
        Me.CheckBox_MetadataCommon_OriginalDocumentHash.Location = New System.Drawing.Point(472, 3)
        Me.CheckBox_MetadataCommon_OriginalDocumentHash.Name = "CheckBox_MetadataCommon_OriginalDocumentHash"
        Me.CheckBox_MetadataCommon_OriginalDocumentHash.Size = New System.Drawing.Size(124, 16)
        Me.CheckBox_MetadataCommon_OriginalDocumentHash.TabIndex = 134
        Me.CheckBox_MetadataCommon_OriginalDocumentHash.Text = "Original Document Hash"
        Me.CheckBox_MetadataCommon_OriginalDocumentHash.UseVisualStyleBackColor = True
        '
        'CheckBox_MetadataCommon_OriginalDocumentPath
        '
        Me.CheckBox_MetadataCommon_OriginalDocumentPath.AutoSize = True
        Me.CheckBox_MetadataCommon_OriginalDocumentPath.Location = New System.Drawing.Point(602, 3)
        Me.CheckBox_MetadataCommon_OriginalDocumentPath.Name = "CheckBox_MetadataCommon_OriginalDocumentPath"
        Me.CheckBox_MetadataCommon_OriginalDocumentPath.Size = New System.Drawing.Size(119, 16)
        Me.CheckBox_MetadataCommon_OriginalDocumentPath.TabIndex = 129
        Me.CheckBox_MetadataCommon_OriginalDocumentPath.Text = "Original Document URI"
        Me.CheckBox_MetadataCommon_OriginalDocumentPath.UseVisualStyleBackColor = True
        '
        'CheckBox_MetadataCommon_PageNumber
        '
        Me.CheckBox_MetadataCommon_PageNumber.AutoSize = True
        Me.CheckBox_MetadataCommon_PageNumber.Location = New System.Drawing.Point(727, 3)
        Me.CheckBox_MetadataCommon_PageNumber.Name = "CheckBox_MetadataCommon_PageNumber"
        Me.CheckBox_MetadataCommon_PageNumber.Size = New System.Drawing.Size(80, 16)
        Me.CheckBox_MetadataCommon_PageNumber.TabIndex = 130
        Me.CheckBox_MetadataCommon_PageNumber.Text = "Page Number"
        Me.CheckBox_MetadataCommon_PageNumber.UseVisualStyleBackColor = True
        '
        'CheckBox_MetadataCommon_PageCount
        '
        Me.CheckBox_MetadataCommon_PageCount.AutoSize = True
        Me.CheckBox_MetadataCommon_PageCount.Location = New System.Drawing.Point(813, 3)
        Me.CheckBox_MetadataCommon_PageCount.Name = "CheckBox_MetadataCommon_PageCount"
        Me.CheckBox_MetadataCommon_PageCount.Size = New System.Drawing.Size(72, 16)
        Me.CheckBox_MetadataCommon_PageCount.TabIndex = 131
        Me.CheckBox_MetadataCommon_PageCount.Text = "Page Count"
        Me.CheckBox_MetadataCommon_PageCount.UseVisualStyleBackColor = True
        '
        'CheckBox_MetadataCommon_TextFileCreatedDate
        '
        Me.CheckBox_MetadataCommon_TextFileCreatedDate.AutoSize = True
        Me.CheckBox_MetadataCommon_TextFileCreatedDate.Location = New System.Drawing.Point(3, 25)
        Me.CheckBox_MetadataCommon_TextFileCreatedDate.Name = "CheckBox_MetadataCommon_TextFileCreatedDate"
        Me.CheckBox_MetadataCommon_TextFileCreatedDate.Size = New System.Drawing.Size(116, 16)
        Me.CheckBox_MetadataCommon_TextFileCreatedDate.TabIndex = 132
        Me.CheckBox_MetadataCommon_TextFileCreatedDate.Text = "Text File Created Date"
        Me.CheckBox_MetadataCommon_TextFileCreatedDate.UseVisualStyleBackColor = True
        Me.CheckBox_MetadataCommon_TextFileCreatedDate.Visible = False
        '
        'GroupBox_Options_TextFile
        '
        Me.GroupBox_Options_TextFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Options_TextFile.Controls.Add(Me.Button_TextFile_Default)
        Me.GroupBox_Options_TextFile.Controls.Add(Me.FlowLayoutPanel_TextOptions)
        Me.GroupBox_Options_TextFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_Options_TextFile.Location = New System.Drawing.Point(11, 9)
        Me.GroupBox_Options_TextFile.Name = "GroupBox_Options_TextFile"
        Me.GroupBox_Options_TextFile.Size = New System.Drawing.Size(979, 127)
        Me.GroupBox_Options_TextFile.TabIndex = 100
        Me.GroupBox_Options_TextFile.TabStop = False
        Me.GroupBox_Options_TextFile.Text = "Text File Options"
        '
        'Button_TextFile_Default
        '
        Me.Button_TextFile_Default.Location = New System.Drawing.Point(11, 25)
        Me.Button_TextFile_Default.Name = "Button_TextFile_Default"
        Me.Button_TextFile_Default.Size = New System.Drawing.Size(52, 22)
        Me.Button_TextFile_Default.TabIndex = 124
        Me.Button_TextFile_Default.Text = "Default"
        Me.Button_TextFile_Default.UseVisualStyleBackColor = True
        '
        'FlowLayoutPanel_TextOptions
        '
        Me.FlowLayoutPanel_TextOptions.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanel_TextOptions.Controls.Add(Me.CheckBox_TextFile_IncludePageNumbers)
        Me.FlowLayoutPanel_TextOptions.Controls.Add(Me.CheckBox_TextFile_LineBreaksPerPage)
        Me.FlowLayoutPanel_TextOptions.Controls.Add(Me.Panel_LineBreaksPerPage)
        Me.FlowLayoutPanel_TextOptions.Controls.Add(Me.CheckBox_TextFile_SplitFilesByPage)
        Me.FlowLayoutPanel_TextOptions.Controls.Add(Me.CheckBox_TextFile_RetainTableStructures)
        Me.FlowLayoutPanel_TextOptions.Controls.Add(Me.Panel_Delimiter)
        Me.FlowLayoutPanel_TextOptions.Controls.Add(Me.CheckBox_TextFile_ReformatTextBlocks)
        Me.FlowLayoutPanel_TextOptions.Controls.Add(Me.Panel_LineBreakPerSentences)
        Me.FlowLayoutPanel_TextOptions.Location = New System.Drawing.Point(11, 56)
        Me.FlowLayoutPanel_TextOptions.Name = "FlowLayoutPanel_TextOptions"
        Me.FlowLayoutPanel_TextOptions.Size = New System.Drawing.Size(959, 61)
        Me.FlowLayoutPanel_TextOptions.TabIndex = 110
        '
        'CheckBox_TextFile_IncludePageNumbers
        '
        Me.CheckBox_TextFile_IncludePageNumbers.AutoSize = True
        Me.CheckBox_TextFile_IncludePageNumbers.Location = New System.Drawing.Point(3, 3)
        Me.CheckBox_TextFile_IncludePageNumbers.Name = "CheckBox_TextFile_IncludePageNumbers"
        Me.CheckBox_TextFile_IncludePageNumbers.Size = New System.Drawing.Size(129, 16)
        Me.CheckBox_TextFile_IncludePageNumbers.TabIndex = 111
        Me.CheckBox_TextFile_IncludePageNumbers.Text = "Include Page Numbers      "
        Me.CheckBox_TextFile_IncludePageNumbers.UseVisualStyleBackColor = True
        '
        'CheckBox_TextFile_LineBreaksPerPage
        '
        Me.CheckBox_TextFile_LineBreaksPerPage.AutoSize = True
        Me.CheckBox_TextFile_LineBreaksPerPage.Location = New System.Drawing.Point(138, 3)
        Me.CheckBox_TextFile_LineBreaksPerPage.Name = "CheckBox_TextFile_LineBreaksPerPage"
        Me.CheckBox_TextFile_LineBreaksPerPage.Size = New System.Drawing.Size(113, 16)
        Me.CheckBox_TextFile_LineBreaksPerPage.TabIndex = 118
        Me.CheckBox_TextFile_LineBreaksPerPage.Text = "Line Breaks per Page:"
        Me.CheckBox_TextFile_LineBreaksPerPage.UseVisualStyleBackColor = True
        Me.CheckBox_TextFile_LineBreaksPerPage.Visible = False
        '
        'Panel_LineBreaksPerPage
        '
        Me.Panel_LineBreaksPerPage.Controls.Add(Me.DomainUpDown_LineBreaksPerPage)
        Me.Panel_LineBreaksPerPage.Enabled = False
        Me.Panel_LineBreaksPerPage.Location = New System.Drawing.Point(257, 3)
        Me.Panel_LineBreaksPerPage.Name = "Panel_LineBreaksPerPage"
        Me.Panel_LineBreaksPerPage.Size = New System.Drawing.Size(62, 21)
        Me.Panel_LineBreaksPerPage.TabIndex = 117
        Me.Panel_LineBreaksPerPage.Visible = False
        '
        'DomainUpDown_LineBreaksPerPage
        '
        Me.DomainUpDown_LineBreaksPerPage.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DomainUpDown_LineBreaksPerPage.Items.Add("5")
        Me.DomainUpDown_LineBreaksPerPage.Items.Add("4")
        Me.DomainUpDown_LineBreaksPerPage.Items.Add("3")
        Me.DomainUpDown_LineBreaksPerPage.Items.Add("2")
        Me.DomainUpDown_LineBreaksPerPage.Items.Add("1")
        Me.DomainUpDown_LineBreaksPerPage.Location = New System.Drawing.Point(0, 0)
        Me.DomainUpDown_LineBreaksPerPage.Name = "DomainUpDown_LineBreaksPerPage"
        Me.DomainUpDown_LineBreaksPerPage.ReadOnly = True
        Me.DomainUpDown_LineBreaksPerPage.Size = New System.Drawing.Size(42, 18)
        Me.DomainUpDown_LineBreaksPerPage.TabIndex = 116
        '
        'CheckBox_TextFile_SplitFilesByPage
        '
        Me.CheckBox_TextFile_SplitFilesByPage.AutoSize = True
        Me.CheckBox_TextFile_SplitFilesByPage.Location = New System.Drawing.Point(325, 3)
        Me.CheckBox_TextFile_SplitFilesByPage.Name = "CheckBox_TextFile_SplitFilesByPage"
        Me.CheckBox_TextFile_SplitFilesByPage.Size = New System.Drawing.Size(111, 16)
        Me.CheckBox_TextFile_SplitFilesByPage.TabIndex = 112
        Me.CheckBox_TextFile_SplitFilesByPage.Text = "Split Files by Page      "
        Me.CheckBox_TextFile_SplitFilesByPage.UseVisualStyleBackColor = True
        '
        'CheckBox_TextFile_RetainTableStructures
        '
        Me.CheckBox_TextFile_RetainTableStructures.AutoSize = True
        Me.CheckBox_TextFile_RetainTableStructures.Location = New System.Drawing.Point(442, 3)
        Me.CheckBox_TextFile_RetainTableStructures.Name = "CheckBox_TextFile_RetainTableStructures"
        Me.CheckBox_TextFile_RetainTableStructures.Size = New System.Drawing.Size(120, 16)
        Me.CheckBox_TextFile_RetainTableStructures.TabIndex = 113
        Me.CheckBox_TextFile_RetainTableStructures.Text = "Retain Table Structures"
        Me.CheckBox_TextFile_RetainTableStructures.UseVisualStyleBackColor = True
        Me.CheckBox_TextFile_RetainTableStructures.Visible = False
        '
        'Panel_Delimiter
        '
        Me.Panel_Delimiter.Controls.Add(Me.DomainUpDown_Delimiter)
        Me.Panel_Delimiter.Controls.Add(Me.Label1)
        Me.Panel_Delimiter.Enabled = False
        Me.Panel_Delimiter.Location = New System.Drawing.Point(568, 3)
        Me.Panel_Delimiter.Name = "Panel_Delimiter"
        Me.Panel_Delimiter.Size = New System.Drawing.Size(126, 21)
        Me.Panel_Delimiter.TabIndex = 116
        Me.Panel_Delimiter.Visible = False
        '
        'DomainUpDown_Delimiter
        '
        Me.DomainUpDown_Delimiter.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DomainUpDown_Delimiter.Items.Add("TAB")
        Me.DomainUpDown_Delimiter.Items.Add("Semi-Colon")
        Me.DomainUpDown_Delimiter.Items.Add("Colon")
        Me.DomainUpDown_Delimiter.Location = New System.Drawing.Point(41, 0)
        Me.DomainUpDown_Delimiter.Name = "DomainUpDown_Delimiter"
        Me.DomainUpDown_Delimiter.ReadOnly = True
        Me.DomainUpDown_Delimiter.Size = New System.Drawing.Size(71, 18)
        Me.DomainUpDown_Delimiter.TabIndex = 116
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(-3, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 12)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Delimiter:"
        '
        'CheckBox_TextFile_ReformatTextBlocks
        '
        Me.CheckBox_TextFile_ReformatTextBlocks.AutoSize = True
        Me.CheckBox_TextFile_ReformatTextBlocks.Location = New System.Drawing.Point(700, 3)
        Me.CheckBox_TextFile_ReformatTextBlocks.Name = "CheckBox_TextFile_ReformatTextBlocks"
        Me.CheckBox_TextFile_ReformatTextBlocks.Size = New System.Drawing.Size(138, 16)
        Me.CheckBox_TextFile_ReformatTextBlocks.TabIndex = 114
        Me.CheckBox_TextFile_ReformatTextBlocks.Text = "Reformat Large Text Blocks"
        Me.CheckBox_TextFile_ReformatTextBlocks.UseVisualStyleBackColor = True
        '
        'Panel_LineBreakPerSentences
        '
        Me.Panel_LineBreakPerSentences.Controls.Add(Me.DomainUpDown_LineBreakPerSentences)
        Me.Panel_LineBreakPerSentences.Controls.Add(Me.Label_TextFile_LineBreakPerSentences)
        Me.Panel_LineBreakPerSentences.Enabled = False
        Me.Panel_LineBreakPerSentences.Location = New System.Drawing.Point(3, 30)
        Me.Panel_LineBreakPerSentences.Name = "Panel_LineBreakPerSentences"
        Me.Panel_LineBreakPerSentences.Size = New System.Drawing.Size(175, 21)
        Me.Panel_LineBreakPerSentences.TabIndex = 115
        '
        'DomainUpDown_LineBreakPerSentences
        '
        Me.DomainUpDown_LineBreakPerSentences.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("20")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("19")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("18")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("17")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("16")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("15")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("14")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("13")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("12")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("11")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("10")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("9")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("8")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("7")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("6")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("5")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("4")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("3")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("2")
        Me.DomainUpDown_LineBreakPerSentences.Items.Add("1")
        Me.DomainUpDown_LineBreakPerSentences.Location = New System.Drawing.Point(114, 0)
        Me.DomainUpDown_LineBreakPerSentences.Name = "DomainUpDown_LineBreakPerSentences"
        Me.DomainUpDown_LineBreakPerSentences.ReadOnly = True
        Me.DomainUpDown_LineBreakPerSentences.Size = New System.Drawing.Size(35, 18)
        Me.DomainUpDown_LineBreakPerSentences.TabIndex = 116
        '
        'Label_TextFile_LineBreakPerSentences
        '
        Me.Label_TextFile_LineBreakPerSentences.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label_TextFile_LineBreakPerSentences.AutoSize = True
        Me.Label_TextFile_LineBreakPerSentences.Location = New System.Drawing.Point(-2, 1)
        Me.Label_TextFile_LineBreakPerSentences.Name = "Label_TextFile_LineBreakPerSentences"
        Me.Label_TextFile_LineBreakPerSentences.Size = New System.Drawing.Size(118, 12)
        Me.Label_TextFile_LineBreakPerSentences.TabIndex = 5
        Me.Label_TextFile_LineBreakPerSentences.Text = "Sentence(s) per Line Break:"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Button_Logging_ClearInAppLog)
        Me.TabPage3.Controls.Add(Me.Button_Logging_ViewLogFile)
        Me.TabPage3.Controls.Add(Me.Panel1_Logging_Output)
        Me.TabPage3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(1001, 502)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Logging"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Button_Logging_ClearInAppLog
        '
        Me.Button_Logging_ClearInAppLog.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Logging_ClearInAppLog.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Logging_ClearInAppLog.Location = New System.Drawing.Point(821, 18)
        Me.Button_Logging_ClearInAppLog.Name = "Button_Logging_ClearInAppLog"
        Me.Button_Logging_ClearInAppLog.Size = New System.Drawing.Size(89, 22)
        Me.Button_Logging_ClearInAppLog.TabIndex = 162
        Me.Button_Logging_ClearInAppLog.Text = "Clear In-App Log"
        Me.Button_Logging_ClearInAppLog.UseVisualStyleBackColor = True
        '
        'Button_Logging_ViewLogFile
        '
        Me.Button_Logging_ViewLogFile.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Logging_ViewLogFile.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Logging_ViewLogFile.Location = New System.Drawing.Point(916, 18)
        Me.Button_Logging_ViewLogFile.Name = "Button_Logging_ViewLogFile"
        Me.Button_Logging_ViewLogFile.Size = New System.Drawing.Size(73, 22)
        Me.Button_Logging_ViewLogFile.TabIndex = 161
        Me.Button_Logging_ViewLogFile.Text = "View Log File"
        Me.Button_Logging_ViewLogFile.UseVisualStyleBackColor = True
        '
        'Panel1_Logging_Output
        '
        Me.Panel1_Logging_Output.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1_Logging_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1_Logging_Output.Controls.Add(Me.RichTextBox_Logging_Output)
        Me.Panel1_Logging_Output.Location = New System.Drawing.Point(14, 45)
        Me.Panel1_Logging_Output.Name = "Panel1_Logging_Output"
        Me.Panel1_Logging_Output.Size = New System.Drawing.Size(975, 445)
        Me.Panel1_Logging_Output.TabIndex = 160
        '
        'RichTextBox_Logging_Output
        '
        Me.RichTextBox_Logging_Output.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox_Logging_Output.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RichTextBox_Logging_Output.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox_Logging_Output.Location = New System.Drawing.Point(0, 0)
        Me.RichTextBox_Logging_Output.Name = "RichTextBox_Logging_Output"
        Me.RichTextBox_Logging_Output.Size = New System.Drawing.Size(973, 443)
        Me.RichTextBox_Logging_Output.TabIndex = 0
        Me.RichTextBox_Logging_Output.Text = ""
        '
        'Button_ConvertAll
        '
        Me.Button_ConvertAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_ConvertAll.Location = New System.Drawing.Point(942, 598)
        Me.Button_ConvertAll.Name = "Button_ConvertAll"
        Me.Button_ConvertAll.Size = New System.Drawing.Size(73, 22)
        Me.Button_ConvertAll.TabIndex = 170
        Me.Button_ConvertAll.Text = "Convert All"
        Me.Button_ConvertAll.UseVisualStyleBackColor = True
        '
        'Button_ConvertSelected
        '
        Me.Button_ConvertSelected.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_ConvertSelected.Location = New System.Drawing.Point(832, 598)
        Me.Button_ConvertSelected.Name = "Button_ConvertSelected"
        Me.Button_ConvertSelected.Size = New System.Drawing.Size(104, 22)
        Me.Button_ConvertSelected.TabIndex = 201
        Me.Button_ConvertSelected.Text = "Convert Selected"
        Me.Button_ConvertSelected.UseVisualStyleBackColor = True
        '
        'CheckBox_Main_LoggingEnabled
        '
        Me.CheckBox_Main_LoggingEnabled.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.CheckBox_Main_LoggingEnabled.AutoSize = True
        Me.CheckBox_Main_LoggingEnabled.Location = New System.Drawing.Point(9, 602)
        Me.CheckBox_Main_LoggingEnabled.Name = "CheckBox_Main_LoggingEnabled"
        Me.CheckBox_Main_LoggingEnabled.Size = New System.Drawing.Size(106, 17)
        Me.CheckBox_Main_LoggingEnabled.TabIndex = 202
        Me.CheckBox_Main_LoggingEnabled.Text = "Logging Enabled"
        Me.CheckBox_Main_LoggingEnabled.UseVisualStyleBackColor = True
        '
        'FormMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1022, 653)
        Me.Controls.Add(Me.CheckBox_Main_LoggingEnabled)
        Me.Controls.Add(Me.Button_ConvertSelected)
        Me.Controls.Add(Me.Button_ConvertAll)
        Me.Controls.Add(Me.TabControlMain)
        Me.Controls.Add(Me.Panel_Parent_Status)
        Me.Controls.Add(Me.Panel_Parent_ToolstripMain)
        Me.Controls.Add(Me.Panel_Parent_MenustripMain)
        Me.MainMenuStrip = Me.MenuStripMain
        Me.MinimumSize = New System.Drawing.Size(600, 600)
        Me.Name = "FormMain"
        Me.Text = "DocStrip"
        Me.Panel_Sources.ResumeLayout(False)
        Me.Panel_Sources.PerformLayout()
        Me.ToolStrip_Sources.ResumeLayout(False)
        Me.ToolStrip_Sources.PerformLayout()
        Me.Panel_Parent_MenustripMain.ResumeLayout(False)
        Me.Panel_Parent_MenustripMain.PerformLayout()
        Me.MenuStripMain.ResumeLayout(False)
        Me.MenuStripMain.PerformLayout()
        Me.GroupBox_Documents_Source.ResumeLayout(False)
        CType(Me.DataGridView_Documents_Sources, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel_Parent_ToolstripMain.ResumeLayout(False)
        Me.Panel_Parent_ToolstripMain.PerformLayout()
        Me.ToolStripMain.ResumeLayout(False)
        Me.ToolStripMain.PerformLayout()
        Me.Panel_Parent_Status.ResumeLayout(False)
        Me.Panel_StatusMessage.ResumeLayout(False)
        Me.Panel_StatusMessage.PerformLayout()
        Me.GroupBox_Documents_DestinationText.ResumeLayout(False)
        Me.Panel_DestinationText_RadioButtonsFilename.ResumeLayout(False)
        Me.Panel_DestinationText_RadioButtonsFilename.PerformLayout()
        Me.Panel_DestinationText_Filename.ResumeLayout(False)
        Me.Panel_DestinationText_Filename.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel_DestinationText_RadioButtonsDirectory.ResumeLayout(False)
        Me.Panel_DestinationText_RadioButtonsDirectory.PerformLayout()
        Me.Panel_DestinationText_Directory.ResumeLayout(False)
        Me.Panel_DestinationText_Directory.PerformLayout()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.TabControlMain.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox_Documents_DestinationMetadata.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel_DestinationMetadata_RadioButtons.ResumeLayout(False)
        Me.Panel_DestinationMetadata_RadioButtons.PerformLayout()
        Me.Panel_DestinationMetadata_Directory.ResumeLayout(False)
        Me.Panel_DestinationMetadata_Directory.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Panel_DestinationMetadata_Checkboxes.ResumeLayout(False)
        Me.Panel_DestinationMetadata_Checkboxes.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox_Options_MetadataCustom.ResumeLayout(False)
        Me.Panel_MetadataCustom_Toolstrip.ResumeLayout(False)
        Me.Panel_MetadataCustom_Toolstrip.PerformLayout()
        Me.ToolStrip_MetadataCustom.ResumeLayout(False)
        Me.ToolStrip_MetadataCustom.PerformLayout()
        CType(Me.DataGridView_Options_MetadataCustom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Options_MetadataCommon.ResumeLayout(False)
        Me.FlowLayoutPanel_MetadataCommonOptions.ResumeLayout(False)
        Me.FlowLayoutPanel_MetadataCommonOptions.PerformLayout()
        Me.GroupBox_Options_TextFile.ResumeLayout(False)
        Me.FlowLayoutPanel_TextOptions.ResumeLayout(False)
        Me.FlowLayoutPanel_TextOptions.PerformLayout()
        Me.Panel_LineBreaksPerPage.ResumeLayout(False)
        Me.Panel_Delimiter.ResumeLayout(False)
        Me.Panel_Delimiter.PerformLayout()
        Me.Panel_LineBreakPerSentences.ResumeLayout(False)
        Me.Panel_LineBreakPerSentences.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.Panel1_Logging_Output.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel_Sources As Panel
    Friend WithEvents Panel_Parent_MenustripMain As Panel
    Friend WithEvents MenuStripMain As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GroupBox_Documents_Source As GroupBox
    Friend WithEvents Panel_Parent_ToolstripMain As Panel
    Friend WithEvents ToolStripMain As ToolStrip
    Friend WithEvents ToolStripButton1 As ToolStripButton
    Friend WithEvents Panel_Parent_Status As Panel
    Friend WithEvents Panel_StatusMessage As Panel
    Friend WithEvents Label_StatusMessage As Label
    Friend WithEvents ProgressBar_Status As ProgressBar
    Friend WithEvents GroupBox_Documents_DestinationText As GroupBox
    Friend WithEvents Panel_DestinationText_Directory As Panel
    Friend WithEvents Button_DestinationText_Browse As Button
    Friend WithEvents Label_DestinationText_Directory As Label
    Friend WithEvents Panel12 As Panel
    Friend WithEvents TextBox_DestinationText_Directory As TextBox
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TabControlMain As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents DataGridView_Documents_Sources As DataGridView
    Friend WithEvents ToolStrip_Sources As ToolStrip
    Friend WithEvents Button_ConvertAll As Button
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents Panel_DestinationText_RadioButtonsDirectory As Panel
    Friend WithEvents RadioButton_DestinationText_Custom As RadioButton
    Friend WithEvents RadioButton_DestinationText_SameOriginFolder As RadioButton
    Friend WithEvents Panel_DestinationText_RadioButtonsFilename As Panel
    Friend WithEvents RadioButton_DestinationText_AppendFilename As RadioButton
    Friend WithEvents RadioButton_DestinationText_SameOriginFile As RadioButton
    Friend WithEvents Panel_DestinationText_Filename As Panel
    Friend WithEvents Label_DestinationText_Filename As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents TextBox_DestinationText_Filename As TextBox
    Friend WithEvents GroupBox_Documents_DestinationMetadata As GroupBox
    Friend WithEvents Panel_DestinationMetadata_RadioButtons As Panel
    Friend WithEvents RadioButton_DestinationMetadata_SameAsPlainText As RadioButton
    Friend WithEvents RadioButton_DestinationMetadata_SameOriginFolder As RadioButton
    Friend WithEvents Panel_DestinationMetadata_Directory As Panel
    Friend WithEvents Button_DestinationMetadata_Browse As Button
    Friend WithEvents Label_DestinationMetadata_Directory As Label
    Friend WithEvents Panel10 As Panel
    Friend WithEvents TextBox_DestinationMetadata_Directory As TextBox
    Friend WithEvents RadioButton_DestinationText_CustomFilename As RadioButton
    Friend WithEvents Panel1_Logging_Output As Panel
    Friend WithEvents RichTextBox_Logging_Output As RichTextBox
    Friend WithEvents CheckBox_TextFile_SplitFilesByPage As CheckBox
    Friend WithEvents CheckBox_TextFile_IncludePageNumbers As CheckBox
    Friend WithEvents GroupBox_Options_MetadataCommon As GroupBox
    Friend WithEvents CheckBox_MetadataCommon_FileType As CheckBox
    Friend WithEvents CheckBox_MetadataCommon_Filename As CheckBox
    Friend WithEvents CheckBox_MetadataCommon_OriginalCreatedDate As CheckBox
    Friend WithEvents CheckBox_MetadataCommon_FileSize As CheckBox
    Friend WithEvents GroupBox_Options_TextFile As GroupBox
    Friend WithEvents GroupBox_Options_MetadataCustom As GroupBox
    Friend WithEvents CheckBox_TextFile_ReformatTextBlocks As CheckBox
    Friend WithEvents Panel_LineBreakPerSentences As Panel
    Friend WithEvents Label_TextFile_LineBreakPerSentences As Label
    Friend WithEvents DomainUpDown_LineBreakPerSentences As DomainUpDown
    Friend WithEvents FlowLayoutPanel_TextOptions As FlowLayoutPanel
    Friend WithEvents FlowLayoutPanel_MetadataCommonOptions As FlowLayoutPanel
    Friend WithEvents DataGridView_Options_MetadataCustom As DataGridView
    Friend WithEvents CheckBox_TextFile_RetainTableStructures As CheckBox
    Friend WithEvents Button_MetadataCommon_None As Button
    Friend WithEvents Button_MetadataCommon_SelectAll As Button
    Friend WithEvents CheckBox_MetadataCommon_OriginalDocumentPath As CheckBox
    Friend WithEvents CheckBox_MetadataCommon_PageNumber As CheckBox
    Friend WithEvents CheckBox_MetadataCommon_PageCount As CheckBox
    Friend WithEvents Button_MetadataCommon_Default As Button
    Friend WithEvents CheckBox_MetadataCommon_TextFileCreatedDate As CheckBox
    Friend WithEvents Key As DataGridViewTextBoxColumn
    Friend WithEvents Value As DataGridViewTextBoxColumn
    Friend WithEvents RadioButton_DestinationMetadata_Custom As RadioButton
    Friend WithEvents Panel_MetadataCustom_Toolstrip As Panel
    Friend WithEvents ToolStrip_MetadataCustom As ToolStrip
    Friend WithEvents ToolStripButton6 As ToolStripButton
    Friend WithEvents ToolStrip_MetadataCustom_Button_DeleteSelected As ToolStripButton
    Friend WithEvents ToolStrip_MetadataCustom_Button_SelectAll As ToolStripButton
    Friend WithEvents Panel_DestinationMetadata_Checkboxes As Panel
    Friend WithEvents CheckBox_DestinationMetadata_GenerateMetadata As CheckBox
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResetApplicationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Button_Logging_ViewLogFile As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel_Delimiter As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents DomainUpDown_Delimiter As DomainUpDown
    Friend WithEvents Button_Logging_ClearInAppLog As Button
    Friend WithEvents ToolStripDropDownButton2 As ToolStripDropDownButton
    Friend WithEvents ByKeyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ByValueToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Button_TextFile_Default As Button
    Friend WithEvents Button_DestinationText_Default As Button
    Friend WithEvents Button_DestinationMetadata_Default As Button
    Friend WithEvents Panel_LineBreaksPerPage As Panel
    Friend WithEvents DomainUpDown_LineBreaksPerPage As DomainUpDown
    Friend WithEvents CheckBox_TextFile_LineBreaksPerPage As CheckBox
    Friend WithEvents Button_ConvertSelected As Button
    Friend WithEvents Label_Sources_DocCountValue As Label
    Friend WithEvents Label_Sources_DocCount As Label
    Friend WithEvents ToolStrip_Sources_Button_DocInfo As ToolStripButton
    Friend WithEvents RadioButton_DestinationText_PrependFilename As RadioButton
    Friend WithEvents CheckBox_Main_LoggingEnabled As CheckBox
    Friend WithEvents ToolStripButton_ManageSources As ToolStripButton
    Friend WithEvents ToolStrip_Sources_Button_Refresh As ToolStripButton
    Friend WithEvents Source As DataGridViewTextBoxColumn
    Friend WithEvents FileType As DataGridViewTextBoxColumn
    Friend WithEvents CheckBox_MetadataCommon_OriginalModifiedDate As CheckBox
    Friend WithEvents CheckBox_MetadataCommon_OriginalDocumentHash As CheckBox
End Class
