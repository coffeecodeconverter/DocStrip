﻿Imports System.ComponentModel

Public Class FormAbout


    Private Sub FormAbout_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label_About_AppVersion.Text = FormMain.applicationVersion
    End Sub



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub



    Private Sub FormAbout_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing

    End Sub

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged

    End Sub
End Class