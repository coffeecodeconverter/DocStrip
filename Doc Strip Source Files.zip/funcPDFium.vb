﻿
Imports PdfiumViewer
Imports System.Runtime.InteropServices
Imports System.Text



Module PDF


    Function GetPDFTextPageCount(pdfPath As String) As Integer
        ' Load the PDF document
        Using document As PdfDocument = PdfDocument.Load(pdfPath)
            Return document.PageCount
        End Using
    End Function





    Function GetPDFInfo(ByVal pdfPath As String) As String
        ' Load the PDF document
        Using document As PdfDocument = PdfDocument.Load(pdfPath)

            ' Get basic document information and display in a message box
            Dim docInfo As PdfInformation = document.GetInformation()
            Dim infoBuilder As New StringBuilder()

            infoBuilder.AppendLine("PDF Document Information:")
            infoBuilder.AppendLine("Title: " & docInfo.Title)
            infoBuilder.AppendLine("Author: " & docInfo.Author)
            infoBuilder.AppendLine("Subject: " & docInfo.Subject)
            infoBuilder.AppendLine("Keywords: " & docInfo.Keywords)
            infoBuilder.AppendLine("Producer: " & docInfo.Producer)
            infoBuilder.AppendLine("Creation Date: " & docInfo.CreationDate)
            infoBuilder.AppendLine("Modification Date: " & docInfo.ModificationDate)

            'MessageBox.Show(infoBuilder.ToString(), "Document Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return infoBuilder.ToString()
        End Using
    End Function




    Function GetPDFTextPages(pdfPath As String, Optional includePageNumbers As Boolean = False, Optional splitFilesPerPage As Boolean = False, Optional reformatTextBlocks As Boolean = False, Optional reformatTextBlocksPerSentences As Integer = 0) As List(Of String)

        Dim documentPages As New List(Of String)
        Dim entireDocText As New System.Text.StringBuilder()

        ' Load the PDF document
        Using document As PdfDocument = PdfDocument.Load(pdfPath)

            ' Iterate through all pages
            For i As Integer = 0 To document.PageCount - 1
                ' Keep UI Elements Updated
                Application.DoEvents()

                ' Build Temp String per Loop Iteration for Each Page
                Dim tempPageText As New System.Text.StringBuilder()

                ' Check if Page Numbers should be included 
                If includePageNumbers Then
                    tempPageText.Append("Page: " & (i + 1) & " of " & document.PageCount & Environment.NewLine)
                End If

                ' Extract text from each page
                Dim extractedText As String = document.GetPdfText(i)

                If reformatTextBlocks AndAlso reformatTextBlocksPerSentences > 0 Then
                    ' Split the text into sentences
                    Dim sentences As String() = extractedText.Split(New Char() {"."c}, StringSplitOptions.RemoveEmptyEntries)
                    Dim formattedText As New System.Text.StringBuilder()
                    Dim sentenceCount As Integer = 0

                    ' Iterate over sentences and add line breaks
                    For Each sentence As String In sentences
                        formattedText.Append(sentence.Trim() & ". ")
                        sentenceCount += 1

                        ' Add a line break after the specified number of sentences
                        If sentenceCount >= reformatTextBlocksPerSentences Then
                            formattedText.AppendLine()
                            formattedText.AppendLine()
                            sentenceCount = 0
                        End If
                    Next

                    tempPageText.Append(formattedText.ToString())
                Else
                    tempPageText.Append(extractedText)
                End If

                ' If splitting Files By Page, append each page as its own List Array Item, otherwise, append all in one go. 
                If splitFilesPerPage Then
                    documentPages.Add(tempPageText.ToString())
                Else
                    entireDocText.Append(tempPageText.ToString() & Environment.NewLine)
                End If

            Next

            ' If Splitting Files Per Page, now append the entire text to the List array.
            If Not splitFilesPerPage Then
                documentPages.Add(entireDocText.ToString())
            End If

        End Using

        ' Return the List Array, which will either be a single page with everything, or separate pages
        Return documentPages

    End Function





End Module
