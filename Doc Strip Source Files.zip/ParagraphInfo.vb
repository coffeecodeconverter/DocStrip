﻿


Imports DocumentFormat.OpenXml.ExtendedProperties
Imports DocumentFormat.OpenXml.Packaging
Imports DocumentFormat.OpenXml.Wordprocessing
Imports System.Text
Imports Microsoft.VisualBasic

Public Class ParagraphInfo
    Public Property Paragraph As Paragraph
    Public Property PageNumber As Integer
End Class
