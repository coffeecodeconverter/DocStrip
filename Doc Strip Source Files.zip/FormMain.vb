﻿

Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Security.Cryptography
Imports System.Text
Imports System.Windows.Forms.VisualStyles.VisualStyleElement
Imports DocumentFormat.OpenXml.Packaging
Imports Newtonsoft.Json



Public Class FormMain


    ' GLOBAL VARIABLES
    ' ===========================================================================
    Public applicationVersion As String = "Version: " & System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString()
    Public enableLogging As Boolean = True

    Public dataGridViewSources_AllSelected As Boolean = False
    Public dataGridViewMetadataCustom_AllSelected As Boolean = False

    ' To Hold Custom Values User has Input 
    Public outputPlainTextDirectory As String = ""
    Public outputPlainTextFileNameOrAppend As String = ""
    Public outputMetadataDirectory As String = ""

    Public showDocInfo As Boolean = False

    ' HashSet to store valid file extensions for fast lookup
    Private validFileExtensions As New HashSet(Of String)(StringComparer.OrdinalIgnoreCase) From {
        ".pdf", ".doc", ".docx", ".txt"
    }
    ' ".pdf", ".doc", ".docx", ".txt", ".rtf", ".html", ".xml"

    Public masterOutputFileExtension As String = ".txt"
    Public masterOutputPageSuffix As String = "_page_"


    ' to Manage the list of File and Folder Sources, that populates the Documents Datagridview. 
    Public GlobalPathsList As New List(Of String)
    Public masterSourceListExportFileName As String = "DocStrip_SourceList"


    ' converstion Checks 
    Public convertSuccess As Boolean = False
    Public suppressWritingFiles As Boolean = False






    ' ===========================================================================
    ' ON FORM LOAD
    ' ===========================================================================
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Log("##### START #####")
        InitializeApp()
    End Sub






    ' =====================================================
    ' FUNCTIONS
    ' =====================================================

    Sub InitializeApp()
        ShowLoading(True)
        Log("Initializing Application...")

        CheckBox_Main_LoggingEnabled.Checked = True

        SetDefaultUIValuesAll()

        Log("Application Initialized.")
        ShowLoading(False)
    End Sub


    Sub ShowLoading(OnOff As Boolean)
        If OnOff = True Then
            ProgressBar_Status.Visible = True
        Else
            ProgressBar_Status.Visible = False
        End If
    End Sub



    Public Sub Log(message As String, Optional logFilePath As String = "")
        If enableLogging = True Then
            ' Use the same directory as this application if no log file path is provided
            If String.IsNullOrEmpty(logFilePath) Then
                logFilePath = IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "DocStrip_" & DateTime.Now.ToString("yyyy-MM-dd") & ".log")
            End If

            ' Ensure that the log directory exists
            Dim logDirectory As String = IO.Path.GetDirectoryName(logFilePath)
            If Not IO.Directory.Exists(logDirectory) Then
                IO.Directory.CreateDirectory(logDirectory)
            End If

            ' Build log message with a timestamp
            Dim logEntry As String = $"{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")} - {message}"

            ' Append the log message to the file
            IO.File.AppendAllText(logFilePath, logEntry & Environment.NewLine)

            ' Also Append the log message to the Richtextbox 
            RichTextBox_Logging_Output.AppendText(logEntry & Environment.NewLine)
        End If
    End Sub



    Public Sub RefreshImportFromSources()

        ' Clear existing rows in the DataGridView
        DataGridView_Documents_Sources.Rows.Clear()

        If GlobalPathsList.Count = 0 Then
            Dim msg As String = "No Sources to Import - Add some first, then retry"
            MessageBox.Show(msg, "No Sources to Import", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Log(msg)
            Exit Sub
        End If

        Dim duplicatesFound As Boolean = False ' Track if any duplicates were found

        ShowLoading(True) ' Optional: Show a loading indicator

        ' Iterate through each path in GlobalPathsList
        For Each path In GlobalPathsList
            ' Keep UI Updated
            Application.DoEvents()

            If IO.Directory.Exists(path) Then
                ' Get all files in the directory and subdirectories
                Dim files As String() = IO.Directory.GetFiles(path, "*.*", SearchOption.AllDirectories)

                For Each filePath As String In files
                    ' Extract the file extension
                    Dim fileExtension As String = IO.Path.GetExtension(filePath)

                    ' Check if the file has a valid extension
                    If validFileExtensions.Contains(fileExtension) Then
                        ' Check for duplicates in the DataGridView
                        Dim isDuplicate As Boolean = False
                        For Each row As DataGridViewRow In DataGridView_Documents_Sources.Rows
                            If row.Cells("source").Value.ToString().Equals(filePath, StringComparison.OrdinalIgnoreCase) Then
                                isDuplicate = True
                                duplicatesFound = True ' Mark that a duplicate was found
                                Exit For
                            End If
                        Next

                        If Not isDuplicate Then
                            ' Add a new row to the DataGridView
                            Dim rowIndex As Integer = DataGridView_Documents_Sources.Rows.Add()
                            Dim newRow As DataGridViewRow = DataGridView_Documents_Sources.Rows(rowIndex)

                            ' Populate the "source" and "File Type" columns
                            newRow.Cells("source").Value = filePath
                            newRow.Cells("FileType").Value = fileExtension

                            ' Log the addition of the valid file
                            Log("Added Document Source file: " & filePath & " (File Type: " & fileExtension & ")")
                        Else
                            ' Log the duplicate file
                            Log("Skipped duplicate file: " & filePath)
                        End If
                    Else
                        ' Log the invalid file type
                        Log("Skipped file with unsupported type: " & filePath & " (File Type: " & fileExtension & ")")
                    End If
                Next

            ElseIf IO.File.Exists(path) Then

                ' The path is a file, so we will process it directly
                Dim filePath As String = path
                ' Extract the file extension
                Dim fileExtension As String = IO.Path.GetExtension(filePath)

                ' Check if the file has a valid extension
                If validFileExtensions.Contains(fileExtension) Then
                    ' Check for duplicates in the DataGridView
                    Dim isDuplicate As Boolean = False
                    For Each row As DataGridViewRow In DataGridView_Documents_Sources.Rows
                        If row.Cells("source").Value.ToString().Equals(filePath, StringComparison.OrdinalIgnoreCase) Then
                            isDuplicate = True
                            duplicatesFound = True ' Mark that a duplicate was found
                            Exit For
                        End If
                    Next

                    If Not isDuplicate Then
                        ' Add a new row to the DataGridView
                        Dim rowIndex As Integer = DataGridView_Documents_Sources.Rows.Add()
                        Dim newRow As DataGridViewRow = DataGridView_Documents_Sources.Rows(rowIndex)

                        ' Populate the "source" and "File Type" columns
                        newRow.Cells("source").Value = filePath
                        newRow.Cells("FileType").Value = fileExtension

                        ' Log the addition of the valid file
                        Log("Added Document Source file: " & filePath & " (File Type: " & fileExtension & ")")
                    Else
                        ' Log the duplicate file
                        Log("Skipped duplicate file: " & filePath)
                    End If
                Else
                    ' Log the invalid file type
                    Log("Skipped file with unsupported type: " & filePath & " (File Type: " & fileExtension & ")")
                End If

            End If
        Next

        ' If duplicates were found, show a single message box
        If duplicatesFound Then
            MessageBox.Show("One or more duplicates were skipped during the refresh.", "Duplicates Skipped", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If

        ShowLoading(False) ' Optional: Hide the loading indicator
        MessageBox.Show("Refreshed Documents from Sources", "Refreshed Document List", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Log("Refreshed Documents from Sources")
    End Sub





    Sub ViewSelectedDocInfo()
        If DataGridView_Documents_Sources.SelectedRows.Count = 0 Then
            MessageBox.Show("Select a Row first", "No Rows Selected", MessageBoxButtons.OK, MessageBoxIcon.Error)

        ElseIf DataGridView_Documents_Sources.SelectedRows.Count = 1 Then
            ' Get the selected row
            Dim selectedRow As DataGridViewRow = DataGridView_Documents_Sources.SelectedRows(0)

            ' Extract the value from the "source" column (can use either column index or name)
            Dim sourceFilePath As String = selectedRow.Cells("source").Value.ToString()

            suppressWritingFiles = True
            ConvertDocumentSources_Selected()
            suppressWritingFiles = False

            ' Proceed with the rest of your logic
            FormTesting.ShowDialog()
        Else
            MessageBox.Show("Only Select a Single Row", "Multiple Rows Selected", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub






    ' SETTING DEFAULT VALUES 
    ' =====================================================

    Sub SetDefaultUIValuesAll()
        SetDefaultUIValuesMainApp()
        SetDefaultUIValuesDocumentSources()
        SetDefaultUIValuesDocumentDestinationText()
        SetDefaultUIValuesDocumentDestinationMetadata()
        SetDefaultUIValuesOptionsTextFile()
        SetDefaultUIValuesOptionsMetadataCommon()
        SetDefaultUIValuesOptionsMetadataCustom()
        Log("Default Values Set")
    End Sub



    Sub SetDefaultUIValuesMainApp()
        Label_StatusMessage.Text = ""

        outputPlainTextDirectory = ""
        outputPlainTextFileNameOrAppend = ""
        outputMetadataDirectory = ""

        CheckBox_Main_LoggingEnabled.Checked = True

        Log("    Reset Main App UI Values to Defaults")
    End Sub



    Sub SetDefaultUIValuesDocumentSources()
        DataGridView_Documents_Sources.Rows.Clear()
        Label_Sources_DocCountValue.Text = "0"
        Log("    Reset Document Sources UI Values to Defaults")
    End Sub



    Sub SetDefaultUIValuesDocumentDestinationText()
        RadioButton_DestinationText_SameOriginFolder.Checked = True
        RadioButton_DestinationText_SameOriginFile.Checked = True
        Log("    Reset Document Destination Text UI Values to Defaults")
    End Sub



    Sub SetDefaultUIValuesDocumentDestinationMetadata()
        CheckBox_DestinationMetadata_GenerateMetadata.Checked = True
        RadioButton_DestinationMetadata_SameOriginFolder.Checked = True
        Log("    Reset Document Destination Metadata UI Values to Defaults")
    End Sub



    Sub SetDefaultUIValuesOptionsTextFile()
        CheckBox_TextFile_IncludePageNumbers.Checked = True
        CheckBox_TextFile_LineBreaksPerPage.Checked = True
        CheckBox_TextFile_SplitFilesByPage.Checked = False
        CheckBox_TextFile_RetainTableStructures.Checked = True
        CheckBox_TextFile_ReformatTextBlocks.Checked = False

        ' Check if the item exists in the DomainUpDown list before selecting it
        If DomainUpDown_LineBreaksPerPage.Items.Contains("1").ToString.ToLower Then
            DomainUpDown_LineBreaksPerPage.SelectedItem = "1"
        End If

        ' Check if the item exists in the DomainUpDown list before selecting it
        If DomainUpDown_Delimiter.Items.Contains("Colon").ToString.ToLower Then
            DomainUpDown_Delimiter.SelectedItem = "Colon"
        End If

        ' You can either use SelectedItem or directly use SelectedIndex
        If DomainUpDown_LineBreakPerSentences.Items.Contains("5") Then
            DomainUpDown_LineBreakPerSentences.SelectedItem = "5"
        End If

        Log("    Reset Text File Option Values to Defaults")
    End Sub



    Sub SelectMetadataCommonValues(tickCheckboxes As Boolean)
        ' Iterate through all controls in the FlowLayoutPanel
        For Each ctrl As Control In FlowLayoutPanel_MetadataCommonOptions.Controls
            ' Check if the control is a CheckBox
            If TypeOf ctrl Is CheckBox Then
                ' Cast the control to a CheckBox and check it
                Dim chk As CheckBox = DirectCast(ctrl, CheckBox)
                If tickCheckboxes = True Then
                    chk.Checked = True
                Else
                    chk.Checked = False
                End If
            End If
        Next
    End Sub


    Sub SetDefaultUIValuesOptionsMetadataCommon()
        CheckBox_MetadataCommon_Filename.Checked = True
        CheckBox_MetadataCommon_FileType.Checked = True
        CheckBox_MetadataCommon_FileSize.Checked = True
        CheckBox_MetadataCommon_OriginalCreatedDate.Checked = True
        CheckBox_MetadataCommon_OriginalModifiedDate.Checked = True
        Log("    Reset Metadata Common Values to Defaults")
    End Sub


    Sub SetDefaultUIValuesOptionsMetadataCustom()
        DataGridView_Options_MetadataCustom.Rows.Clear()
        Log("    Reset Metadata Custom Values to Defaults")
    End Sub










    ' CONVERSION FUNCTIONS
    ' =====================================================

    Sub ConvertDocumentSources_Selected()
        ' Check at least 1 x Row Exists
        If DataGridView_Documents_Sources.Rows.Count = 0 Then
            Dim msg = "No Document Sources to Convert - Add some documents then retry"
            MessageBox.Show(msg, "No Document Sources", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Log(msg)
            Exit Sub
        End If

        ' Check at least 1 x Row is Selected
        If DataGridView_Documents_Sources.SelectedRows.Count = 0 Then
            Dim msg = "No Document Sources Selected to Convert - Select one or more documents in the list, then retry"
            MessageBox.Show(msg, "No Document Sources Selected", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Log(msg)
            Exit Sub
        End If

        ' Iterate through all SELECTED rows
        Dim iterationNum As Integer = 1
        For Each selectedRow As DataGridViewRow In DataGridView_Documents_Sources.SelectedRows
            ChooseFunctionForFileType(selectedRow, iterationNum)
            iterationNum += 1
        Next
    End Sub






    Sub ConvertDocumentSources_All()
        ' Check at least 1 x Row Exists
        If DataGridView_Documents_Sources.Rows.Count = 0 Then
            Dim msg = "No Document Sources to Convert - Add some documents then retry"
            MessageBox.Show(msg, "No Document Sources", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Log(msg)
            Exit Sub
        End If

        ' Iterate through ALL rows
        Dim iterationNum As Integer = 1
        For Each row As DataGridViewRow In DataGridView_Documents_Sources.Rows
            ChooseFunctionForFileType(row, iterationNum)
            iterationNum += 1
        Next
    End Sub






    Sub ChooseFunctionForFileType(dataGridViewRow As DataGridViewRow, iterationNum As Integer)
        ' Get the file type from the row
        Dim fileType As String = dataGridViewRow.Cells("FileType").Value.ToString()
        Dim fileSource As String = dataGridViewRow.Cells("Source").Value.ToString()

        ' Use Select Case to determine the action based on file type
        Select Case fileType.ToLower()
            Case ".pdf"
                ConvertDocumentSource_PDF(fileSource, iterationNum)

            Case ".doc", ".docx"
                'MsgBox("The file type is Word Document.")
                ConvertDocumentSource_WordDoc(fileSource, iterationNum)

            Case ".txt"
                'MsgBox("The file type is Text File.")
                ConvertDocumentSource_TXT(fileSource, iterationNum)

            Case ".rtf"
                MsgBox("The file type is RTF File.")

            Case ".csv"
                MsgBox("The file type is CSV File.")

            Case ".html"
                MsgBox("The file type is HTML File.")

            Case ".json"
                MsgBox("The file type is JSON File.")

            Case ".xml"
                MsgBox("The file type is XML File.")

            Case Else
                MsgBox("Unknown file type: " & fileType)
        End Select
    End Sub







    Sub ConvertDocumentSource_PDF(sourceDocFullFilePath As String, rowNumber As Integer)

        ' CONFIRM SETTINGS
        Dim pageCount As Integer = GetPDFTextPageCount(sourceDocFullFilePath)
        FormTesting.TextBox_PageCount.Text = pageCount

        Dim pdfInfo As String = GetPDFInfo(sourceDocFullFilePath)
        FormTesting.RichTextBox_DocumentInfo.Text = pdfInfo
        'FormTesting.RichTextBox_TestingOutput.Text = pdfInfo

        Dim includePageNumbers As Boolean = CheckBox_TextFile_IncludePageNumbers.Checked
        Dim splitFilesPerPage As Boolean = CheckBox_TextFile_SplitFilesByPage.Checked

        Dim reformatLargeTextBlocks As Boolean = CheckBox_TextFile_ReformatTextBlocks.Checked
        Dim reformatLargeTextPerSentences As Integer = 0
        If reformatLargeTextBlocks = True Then
            reformatLargeTextPerSentences = CInt(DomainUpDown_LineBreakPerSentences.SelectedItem.ToString())
        End If

        ' GATHER DOCUMENT PLAIN TEXT
        Dim pdfPages As List(Of String) = GetPDFTextPages(sourceDocFullFilePath, includePageNumbers, splitFilesPerPage, reformatLargeTextBlocks, reformatLargeTextPerSentences)


        ' ASCERTAIN OUTPUT DIRECTORY
        Dim outputDirectory As String = ""
        If RadioButton_DestinationText_SameOriginFolder.Checked = True Then
            ' Use Source Directory
            outputDirectory = Path.GetDirectoryName(sourceDocFullFilePath)

        Else
            ' Use Custom Directory
            If TextBox_DestinationText_Directory.Text = "" Then
                Dim msg As String = "Custom Directory Empty - Enter a Folder path or Browse to one."
                MessageBox.Show(msg, "Missing Custom Directory", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Log(msg)
                convertSuccess = False
                Exit Sub

            Else
                If Directory.Exists(Path.GetDirectoryName(TextBox_DestinationText_Directory.Text)) Then
                    outputDirectory = Path.GetDirectoryName(TextBox_DestinationText_Directory.Text)
                Else
                    Dim msg As String = "Custom Directory specified does not exist - Enter a valid Folder path"
                    MessageBox.Show(msg, "Custom Directory Does Not Exist", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Log(msg)
                    convertSuccess = False
                    Exit Sub
                End If

            End If
        End If


        ' ASCERTAIN OUTPUT FILE NAMES
        Dim sourceDocFileName As String = Path.GetFileNameWithoutExtension(sourceDocFullFilePath)
        Dim outputFileName As String = ""
        Dim outputFileNameIncrement As Integer = 1
        Dim newFileFullPath As String = ""


        ' Determine base filename based on selected options
        If RadioButton_DestinationText_CustomFilename.Checked Then
            ' Use custom filename provided in the textbox
            outputFileName = Path.GetFileNameWithoutExtension(TextBox_DestinationText_Filename.Text) & "_" & rowNumber
            MsgBox("Custom file name" & vbCrLf & outputFileName)

        ElseIf RadioButton_DestinationText_prependFilename.Checked Then
            ' Append custom text from the textbox to the source file name
            outputFileName = Path.GetFileNameWithoutExtension(TextBox_DestinationText_Filename.Text) & sourceDocFileName

        ElseIf RadioButton_DestinationText_AppendFilename.Checked Then
            ' Append custom text from the textbox to the source file name
            outputFileName = sourceDocFileName & Path.GetFileNameWithoutExtension(TextBox_DestinationText_Filename.Text)
        Else
            ' Default to the original source file name
            outputFileName = sourceDocFileName
        End If


        ' Handle file writing, based on whether we're splitting files per page or writing everything into one file
        If splitFilesPerPage = True Then
            ' If splitting per page, generate a different file name for each page
            For pageNum As Integer = 1 To pdfPages.Count
                ' Append the page number suffix to the filename for each page
                Dim splitFileName As String = Path.GetFileNameWithoutExtension(outputFileName) & masterOutputPageSuffix & pageNum & masterOutputFileExtension
                newFileFullPath = Path.Combine(outputDirectory, splitFileName)

                ' Determine the corresponding metadata file name for this page based on radio button selection
                Dim metadataFileName As String = Path.GetFileNameWithoutExtension(outputFileName) & masterOutputPageSuffix & pageNum & ".meta"
                Dim metadataFileFullPath As String = ""

                ' Set metadata file path based on selected radio button
                If RadioButton_DestinationMetadata_SameOriginFolder.Checked = True Then
                    metadataFileFullPath = Path.Combine(outputDirectory, metadataFileName)
                ElseIf RadioButton_DestinationMetadata_SameAsPlainText.Checked = True Then
                    metadataFileFullPath = Path.Combine(outputPlainTextFileNameOrAppend, metadataFileName)
                ElseIf RadioButton_DestinationMetadata_Custom.Checked = True Then
                    metadataFileFullPath = Path.Combine(outputMetadataDirectory, metadataFileName)
                End If

                If suppressWritingFiles = False Then
                    ' Write each page to a separate file
                    WriteDocumentPlainText(newFileFullPath, pdfPages(pageNum - 1))

                    ' Generate metadata for each page, but reference the original PDF document for metadata
                    If CheckBox_DestinationMetadata_GenerateMetadata.Checked = True Then
                        GenerateDocumentMetadata(sourceDocFullFilePath, metadataFileFullPath, pageNum, pdfPages.Count)
                    End If
                End If
                FormTesting.RichTextBox_TestingOutput.Text = pdfPages(pageNum - 1)
            Next
        Else
            ' Single file mode (no split per page)
            newFileFullPath = Path.Combine(outputDirectory, outputFileName & masterOutputFileExtension)
            Dim metadataFileFullPath As String = ""
            Dim metadataFileName As String = Path.GetFileNameWithoutExtension(outputFileName) & ".meta"

            ' Set metadata file path based on selected radio button
            If RadioButton_DestinationMetadata_SameOriginFolder.Checked = True Then
                metadataFileFullPath = Path.Combine(outputDirectory, metadataFileName)
            ElseIf RadioButton_DestinationMetadata_SameAsPlainText.Checked = True Then
                metadataFileFullPath = Path.Combine(outputPlainTextFileNameOrAppend, metadataFileName)
            ElseIf RadioButton_DestinationMetadata_Custom.Checked = True Then
                metadataFileFullPath = Path.Combine(outputMetadataDirectory, metadataFileName)
            End If

            ' Write all pages to a single file
            For Each page In pdfPages
                If suppressWritingFiles = False Then
                    WriteDocumentPlainText(newFileFullPath, page)
                End If
                FormTesting.RichTextBox_TestingOutput.Text = page
            Next

            ' Generate metadata for the single file (referencing the original PDF document)
            If CheckBox_DestinationMetadata_GenerateMetadata.Checked = True Then
                GenerateDocumentMetadata(sourceDocFullFilePath, metadataFileFullPath)
            End If
        End If

        convertSuccess = True
    End Sub







    Sub ConvertDocumentSource_TXT(sourceDocFullFilePath As String, rowNumber As Integer)

        ' CONFIRM SETTINGS
        Dim reformatLargeTextBlocks As Boolean = CheckBox_TextFile_ReformatTextBlocks.Checked
        Dim reformatLargeTextPerSentences As Integer = 0
        If reformatLargeTextBlocks = True Then
            reformatLargeTextPerSentences = CInt(DomainUpDown_LineBreakPerSentences.SelectedItem.ToString())
        End If

        ' GATHER DOCUMENT PLAIN TEXT
        Dim pdfPages As New List(Of String)
        pdfPages.Add(ReadFileToString(sourceDocFullFilePath, reformatLargeTextBlocks, reformatLargeTextPerSentences))


        ' ASCERTAIN OUTPUT DIRECTORY
        Dim outputDirectory As String = ""
        If RadioButton_DestinationText_SameOriginFolder.Checked = True Then
            ' Use Source Directory
            outputDirectory = Path.GetDirectoryName(sourceDocFullFilePath)

        Else
            ' Use Custom Directory
            If TextBox_DestinationText_Directory.Text = "" Then
                Dim msg As String = "Custom Directory Empty - Enter a Folder path or Browse to one."
                MessageBox.Show(msg, "Missing Custom Directory", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Log(msg)
                convertSuccess = False
                Exit Sub

            Else
                If Directory.Exists(Path.GetDirectoryName(TextBox_DestinationText_Directory.Text)) Then
                    outputDirectory = Path.GetDirectoryName(TextBox_DestinationText_Directory.Text)
                Else
                    Dim msg As String = "Custom Directory specified does not exist - Enter a valid Folder path"
                    MessageBox.Show(msg, "Custom Directory Does Not Exist", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Log(msg)
                    convertSuccess = False
                    Exit Sub
                End If

            End If
        End If


        ' ASCERTAIN OUTPUT FILE NAMES
        Dim sourceDocFileName As String = Path.GetFileNameWithoutExtension(sourceDocFullFilePath)
        Dim outputFileName As String = ""
        Dim outputFileNameIncrement As Integer = 1
        Dim newFileFullPath As String = ""


        ' Determine base filename based on selected options
        If RadioButton_DestinationText_CustomFilename.Checked Then
            ' Use custom filename provided in the textbox
            outputFileName = Path.GetFileNameWithoutExtension(TextBox_DestinationText_Filename.Text) & "_" & rowNumber
            MsgBox("Custom file name" & vbCrLf & outputFileName)

        ElseIf RadioButton_DestinationText_PrependFilename.Checked Then
            ' Append custom text from the textbox to the source file name
            outputFileName = Path.GetFileNameWithoutExtension(TextBox_DestinationText_Filename.Text) & sourceDocFileName

        ElseIf RadioButton_DestinationText_AppendFilename.Checked Then
            ' Append custom text from the textbox to the source file name
            outputFileName = sourceDocFileName & Path.GetFileNameWithoutExtension(TextBox_DestinationText_Filename.Text)
        Else
            ' Default to the original source file name
            outputFileName = Path.GetFileNameWithoutExtension(sourceDocFileName) & ".txt.clean"
        End If



        ' Single file mode (no split per page)
        newFileFullPath = Path.Combine(outputDirectory, outputFileName & masterOutputFileExtension)
        Dim metadataFileFullPath As String = ""
        Dim metadataFileName As String = Path.GetFileNameWithoutExtension(outputFileName) & ".meta"

        ' Set metadata file path based on selected radio button
        If RadioButton_DestinationMetadata_SameOriginFolder.Checked = True Then
            metadataFileFullPath = Path.Combine(outputDirectory, metadataFileName)
        ElseIf RadioButton_DestinationMetadata_SameAsPlainText.Checked = True Then
            metadataFileFullPath = Path.Combine(outputPlainTextFileNameOrAppend, metadataFileName)
        ElseIf RadioButton_DestinationMetadata_Custom.Checked = True Then
            metadataFileFullPath = Path.Combine(outputMetadataDirectory, metadataFileName)
        End If

        ' Write all pages to a single file
        For Each page In pdfPages
            If suppressWritingFiles = False Then
                WriteDocumentPlainText(newFileFullPath, page)
            End If
            FormTesting.RichTextBox_TestingOutput.Text = page
        Next

        ' Generate metadata for the single file (referencing the original PDF document)
        If CheckBox_DestinationMetadata_GenerateMetadata.Checked = True Then
            GenerateDocumentMetadata(sourceDocFullFilePath, metadataFileFullPath)
        End If

        convertSuccess = True
    End Sub








    Sub ConvertDocumentSource_WordDoc(sourceDocFullFilePath As String, rowNumber As Integer)

        ShowLoading(True)

        ' CONFIRM SETTINGS
        Dim wordDoc As WordprocessingDocument = Nothing
        Try
            wordDoc = WordprocessingDocument.Open(sourceDocFullFilePath, False)
        Catch ex As Exception
            MessageBox.Show("ERROR opening Word Document: " & vbCrLf & sourceDocFullFilePath & vbCrLf & vbCrLf & ex.Message)
            Exit Sub
        End Try

        Dim pageCount As Integer = GetWordDocumentPageCount(wordDoc) ' Use the new page count function
        FormTesting.TextBox_PageCount.Text = pageCount.ToString()

        Dim wordInfo As String = GetWordDocumentInfo(sourceDocFullFilePath)
        FormTesting.RichTextBox_DocumentInfo.Text = wordInfo

        Dim includePageNumbers As Boolean = CheckBox_TextFile_IncludePageNumbers.Checked
        Dim splitFilesPerPage As Boolean = CheckBox_TextFile_SplitFilesByPage.Checked

        Dim reformatLargeTextBlocks As Boolean = CheckBox_TextFile_ReformatTextBlocks.Checked
        Dim reformatLargeTextPerSentences As Integer = 0
        If reformatLargeTextBlocks = True Then
            reformatLargeTextPerSentences = CInt(DomainUpDown_LineBreakPerSentences.SelectedItem.ToString())
        End If

        ' GATHER DOCUMENT PLAIN TEXT
        System.Windows.Forms.Application.DoEvents()
        Dim wordPages As List(Of String) = GetWordDocumentTextPages(sourceDocFullFilePath, includePageNumbers, splitFilesPerPage, reformatLargeTextBlocks, reformatLargeTextPerSentences)

        ' ASCERTAIN OUTPUT DIRECTORY
        Dim outputDirectory As String = ""
        If RadioButton_DestinationText_SameOriginFolder.Checked Then
            outputDirectory = Path.GetDirectoryName(sourceDocFullFilePath)
        Else
            If String.IsNullOrWhiteSpace(TextBox_DestinationText_Directory.Text) Then
                MessageBox.Show("Custom Directory Empty - Enter a Folder path or Browse to one.", "Missing Custom Directory", MessageBoxButtons.OK, MessageBoxIcon.Error)
                convertSuccess = False
                Exit Sub
            Else
                If Directory.Exists(Path.GetDirectoryName(TextBox_DestinationText_Directory.Text)) Then
                    outputDirectory = Path.GetDirectoryName(TextBox_DestinationText_Directory.Text)
                Else
                    MessageBox.Show("Custom Directory specified does not exist - Enter a valid Folder path", "Custom Directory Does Not Exist", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    convertSuccess = False
                    Exit Sub
                End If
            End If
        End If

        ' ASCERTAIN OUTPUT FILE NAMES
        Dim sourceDocFileName As String = Path.GetFileNameWithoutExtension(sourceDocFullFilePath)
        Dim outputFileName As String = ""
        Dim newFileFullPath As String = ""


        ' Determine base filename based on selected options
        If RadioButton_DestinationText_CustomFilename.Checked Then
            outputFileName = Path.GetFileNameWithoutExtension(TextBox_DestinationText_Filename.Text) & "_" & rowNumber
        ElseIf RadioButton_DestinationText_PrependFilename.Checked Then
            outputFileName = Path.GetFileNameWithoutExtension(TextBox_DestinationText_Filename.Text) & sourceDocFileName
        ElseIf RadioButton_DestinationText_AppendFilename.Checked Then
            outputFileName = sourceDocFileName & Path.GetFileNameWithoutExtension(TextBox_DestinationText_Filename.Text)
        Else
            outputFileName = sourceDocFileName
        End If


        Dim metadataFileFullPath As String = ""

        'If splitFilesPerPage = True Then
        '    ' If splitting per page, generate a different file name for each page
        '    For pageNum As Integer = 1 To wordPages.Count
        '        System.Windows.Forms.Application.DoEvents()
        '        ' Append the page number suffix to the filename for each page
        '        Dim splitFileName As String = Path.GetFileNameWithoutExtension(outputFileName) & "_Page" & pageNum & ".txt"
        '        newFileFullPath = Path.Combine(outputDirectory, splitFileName)

        '        ' Determine the corresponding metadata file name for this page based on radio button selection
        '        Dim metadataFileName As String = Path.GetFileNameWithoutExtension(outputFileName) & "_Page" & pageNum & ".meta"
        '        'Dim metadataFileFullPath As String = ""

        '        ' Set metadata file path based on selected radio button
        '        If RadioButton_DestinationMetadata_SameOriginFolder.Checked = True Then
        '            metadataFileFullPath = Path.Combine(outputDirectory, metadataFileName)
        '        ElseIf RadioButton_DestinationMetadata_SameAsPlainText.Checked = True Then
        '            metadataFileFullPath = Path.Combine(outputPlainTextFileNameOrAppend, metadataFileName)
        '        ElseIf RadioButton_DestinationMetadata_Custom.Checked = True Then
        '            metadataFileFullPath = Path.Combine(outputMetadataDirectory, metadataFileName)
        '        End If

        '        ' Write each page to a separate file
        '        If suppressWritingFiles = False Then
        '            WriteDocumentPlainText(newFileFullPath, wordPages(pageNum - 1))
        '        End If

        '        ' Generate metadata for each page, but reference the original Word document for metadata
        '        If CheckBox_DestinationMetadata_GenerateMetadata.Checked = True Then
        '            GenerateDocumentMetadata(sourceDocFullFilePath, metadataFileFullPath, pageNum, wordPages.Count)
        '        End If

        '        ' Output content to the rich text box for testing
        '        FormTesting.RichTextBox_TestingOutput.Text = wordPages(pageNum - 1)
        '    Next
        'Else
        ' Single file mode (no split per page)
        newFileFullPath = Path.Combine(outputDirectory, outputFileName & ".txt")
            'Dim metadataFileFullPath As String = ""
            Dim metadataFileName As String = Path.GetFileNameWithoutExtension(outputFileName) & ".meta"

            ' Set metadata file path based on selected radio button
            If RadioButton_DestinationMetadata_SameOriginFolder.Checked = True Then
                metadataFileFullPath = Path.Combine(outputDirectory, metadataFileName)
            ElseIf RadioButton_DestinationMetadata_SameAsPlainText.Checked = True Then
                metadataFileFullPath = Path.Combine(outputPlainTextFileNameOrAppend, metadataFileName)
            ElseIf RadioButton_DestinationMetadata_Custom.Checked = True Then
                metadataFileFullPath = Path.Combine(outputMetadataDirectory, metadataFileName)
            End If

            Dim pageBuilder As New StringBuilder()

            If suppressWritingFiles = False Then

                ' Write all pages to a single file
                For pageNum As Integer = 1 To wordPages.Count
                    System.Windows.Forms.Application.DoEvents()
                    If wordPages(pageNum - 1).ToString.Contains("●") Then
                        Dim tempString As String = wordPages(pageNum - 1).ToString.Replace("●", vbCrLf & "●")
                    pageBuilder.Append(tempString)
                Else
                    pageBuilder.Append(wordPages(pageNum - 1) & " ")
                End If
                Next

                WriteDocumentPlainText(newFileFullPath, pageBuilder.ToString)

                ' Output content to the rich text box for testing
                FormTesting.RichTextBox_TestingOutput.Text = pageBuilder.ToString
                pageBuilder.Clear()
            End If

            ' Generate metadata for the single file (referencing the original Word document)
            If CheckBox_DestinationMetadata_GenerateMetadata.Checked = True Then
                GenerateDocumentMetadata(sourceDocFullFilePath, metadataFileFullPath)
            End If
        'End If

        convertSuccess = True
        ShowLoading(False)
    End Sub











    Function ReadFileToString(filePath As String, reformatTextBlocks As Boolean, reformatTextBlocksPerSentences As Integer) As String
        ' Create a buffer for reading the file in chunks
        Dim buffer As Byte() = New Byte(8191) {}
        Dim encoding As Encoding = Encoding.UTF8 ' Assuming the file is UTF-8 encoded
        Dim result As String

        ' Using a MemoryStream to store the file content
        Using memoryStream As New MemoryStream()
            Using fileStream As New FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read)
                Dim bytesRead As Integer

                ' Read the file in chunks until the end of the file
                Do
                    bytesRead = fileStream.Read(buffer, 0, buffer.Length)
                    If bytesRead > 0 Then
                        memoryStream.Write(buffer, 0, bytesRead)
                    End If
                Loop While bytesRead > 0
            End Using

            ' Convert the MemoryStream to a string
            result = encoding.GetString(memoryStream.ToArray())
        End Using

        ' Now apply reformatting if necessary
        If reformatTextBlocks AndAlso reformatTextBlocksPerSentences > 0 Then
            ' Split the text into sentences
            Dim sentences As String() = result.Split(New Char() {"."c}, StringSplitOptions.RemoveEmptyEntries)
            Dim formattedText As New StringBuilder()
            Dim sentenceCount As Integer = 0

            ' Iterate over sentences and add line breaks
            For Each sentence As String In sentences
                formattedText.Append(sentence.Trim() & ". ")
                sentenceCount += 1

                ' Add a line break after the specified number of sentences
                If sentenceCount >= reformatTextBlocksPerSentences Then
                    formattedText.AppendLine()
                    formattedText.AppendLine()
                    sentenceCount = 0
                End If
            Next

            ' Return the formatted text
            Return formattedText.ToString()
        Else
            ' If no reformatting is required, return the original file content
            Return result
        End If
    End Function







    Sub WriteDocumentPlainText(fullFilePath As String, textToWrite As String)
        Try
            ' Get the directory and filename without the extension
            Dim directory As String = IO.Path.GetDirectoryName(fullFilePath)
            Dim fileNameWithoutExtension As String = IO.Path.GetFileNameWithoutExtension(fullFilePath)

            ' Define the new .txt file path
            Dim txtFilePath As String = IO.Path.Combine(directory, fileNameWithoutExtension & ".txt")

            ' Write the text to the .txt file
            IO.File.WriteAllText(txtFilePath, textToWrite)

            ' Log the file saving
            Log("Text file saved: " & txtFilePath)

        Catch ex As Exception
            ' Handle exceptions (e.g., file access issues)
            MessageBox.Show("Error writing text file: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Log("Error writing text file: " & ex.Message)
        End Try
    End Sub




    Sub WriteDocumentMetadata(metadataFilePath As String, textToWrite As String)
        Try
            ' Write the metadata to the specified .meta file
            IO.File.WriteAllText(metadataFilePath, textToWrite)

            ' Log the file saving
            Log("Metadata file saved: " & metadataFilePath)

        Catch ex As Exception
            ' Handle exceptions (e.g., file access issues)
            MessageBox.Show("Error writing text file: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Log("Error writing text file: " & ex.Message)
        End Try
    End Sub





    Sub GenerateDocumentMetadata(originalDocumentFilePath As String, metadataFilePath As String, Optional pageNum As Integer = -1, Optional pageTotal As Integer = -1)
        Try
            ' Check if the original document exists
            If Not File.Exists(originalDocumentFilePath) Then
                Throw New FileNotFoundException("Original PDF file not found.", originalDocumentFilePath)
            End If

            ' Get the file info from the original PDF
            Dim originalFileInfo As New FileInfo(originalDocumentFilePath)

            ' Get the hash of the original PDF document
            Dim fileHash As String = ComputeFileHash(originalDocumentFilePath)

            ' Format the created and modified dates as DD-MM-YYYY HH:mm:ss.uuu from the original PDF
            Dim createdDateFormatted As String = originalFileInfo.CreationTime.ToString("dd-MM-yyyy HH:mm:ss.fff")
            Dim modifiedDateFormatted As String = originalFileInfo.LastWriteTime.ToString("dd-MM-yyyy HH:mm:ss.fff")

            ' Create a dictionary for metadata (use Dictionary to allow dynamic property inclusion)
            Dim metadata As New Dictionary(Of String, Object)

            ' Add common metadata based on checkboxes
            If CheckBox_MetadataCommon_Filename.Checked Then
                metadata("fileName") = originalFileInfo.Name ' PDF name, not the text file name
            End If

            If CheckBox_MetadataCommon_FileSize.Checked Then
                metadata("fileSize") = originalFileInfo.Length ' PDF file size
            End If

            If CheckBox_MetadataCommon_FileType.Checked Then
                metadata("fileType") = originalFileInfo.Extension ' PDF extension
            End If

            If CheckBox_MetadataCommon_OriginalCreatedDate.Checked Then
                metadata("createdDate") = createdDateFormatted ' PDF creation date
            End If

            If CheckBox_MetadataCommon_OriginalModifiedDate.Checked Then
                metadata("modifiedDate") = modifiedDateFormatted ' PDF modified date
            End If

            If CheckBox_MetadataCommon_OriginalDocumentHash.Checked Then
                metadata("fileHash") = fileHash ' PDF hash
            End If

            If CheckBox_MetadataCommon_OriginalDocumentPath.Checked Then
                metadata("URI") = New Uri(originalFileInfo.FullName).AbsoluteUri
            End If

            If pageNum <> -1 AndAlso pageTotal <> -1 Then
                If CheckBox_MetadataCommon_PageNumber.Checked Then
                    metadata("PageNum") = pageNum ' Page number for split text
                End If

                If CheckBox_MetadataCommon_PageCount.Checked Then
                    metadata("PageTotal") = pageTotal ' Total pages for split text
                End If
            End If

            ' Add custom metadata from DataGridView
            For Each row As DataGridViewRow In DataGridView_Options_MetadataCustom.Rows
                If Not row.IsNewRow Then ' Ignore the new row placeholder
                    Dim key As String = Convert.ToString(row.Cells("Key").Value)?.Trim()
                    Dim value As String = Convert.ToString(row.Cells("Value").Value)?.Trim()

                    If Not String.IsNullOrEmpty(key) AndAlso Not String.IsNullOrEmpty(value) Then
                        metadata(key) = value ' Add custom key-value pairs
                    End If
                End If
            Next

            ' Convert metadata to JSON format
            Dim jsonMetadata As String = JsonConvert.SerializeObject(metadata, Formatting.Indented)

            ' Write the JSON metadata to the specified .meta file
            WriteDocumentMetadata(metadataFilePath, jsonMetadata)

        Catch ex As Exception
            ' Handle exceptions (e.g., file access issues)
            MessageBox.Show("Error generating document metadata: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Log("Error generating document metadata: " & ex.Message)
        End Try
    End Sub






    ' Function to compute the SHA-256 hash of a file
    Function ComputeFileHash(filePath As String) As String
        Using sha256 As SHA256 = sha256.Create()
            Using fileStream As FileStream = File.OpenRead(filePath)
                ' Compute the hash as a byte array
                Dim hashBytes As Byte() = sha256.ComputeHash(fileStream)
                ' Convert the byte array to a hexadecimal string
                Dim hashStringBuilder As New StringBuilder()
                For Each b As Byte In hashBytes
                    hashStringBuilder.Append(b.ToString("x2"))
                Next
                Return hashStringBuilder.ToString()
            End Using
        End Using
    End Function











    ' MENUSTRIP - MAIN
    ' =====================================================

    ' MENUSTRIP - File > Exit 
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    ' MENUSTRIP - Edit > Reset Application 
    Private Sub ResetApplicationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResetApplicationToolStripMenuItem.Click
        Dim msg = "Reset Application to Default Values?"
        Dim answer = MessageBox.Show(msg, "Reset Application?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        Log(msg)
        If answer = vbYes Then
            answer = MessageBox.Show("Are you Sure?", "Confirm Reset Application?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If answer = vbYes Then
                Log("Answered: YES")
                SetDefaultUIValuesAll()
            Else
                Log("Answered: NO")
            End If
        Else
            Log("Answered: NO")
        End If
    End Sub


    ' MENUSTRIP - Edit > Enable / Disable Logging 

    ' MENUSTRIP - Help > View Logs 
    Private Sub VToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VToolStripMenuItem.Click
        OpenLogFile()
    End Sub


    ' MENUSTRIP - Help > About 
    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        FormAbout.ShowDialog()
    End Sub






    ' TOOLSTRIP - MAIN
    ' =====================================================

    ' TOOLSTRIP MAIN - Button 1
    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click

    End Sub





    ' DOCUMENTS - SOURCES - TOOLSTRIP
    ' =====================================================

    ' TOOLSTRIP SOURCES - Add Documents
    Private Sub ToolStripButton_AddSources_Click(sender As Object, e As EventArgs) Handles ToolStripButton_ManageSources.Click
        FormManageSources.ShowDialog()
        FormManageSources.UpdateGlobalPaths()
        RefreshImportFromSources()
    End Sub


    ' TOOLSTRIP SOURCES - Refresh Import Documents
    Private Sub ToolStrip_Sources_Button_Refresh_Click(sender As Object, e As EventArgs) Handles ToolStrip_Sources_Button_Refresh.Click
        RefreshImportFromSources()
    End Sub



    ' TOOLSTRIP SOURCES - Show Document Info
    Private Sub ToolStrip_Sources_Button_DocInfo_Click(sender As Object, e As EventArgs) Handles ToolStrip_Sources_Button_DocInfo.Click
        ViewSelectedDocInfo()
    End Sub





    ' DOCUMENTS - SOURCES - DATAGRID VIEW
    ' =====================================================

    Private Sub DataGridView_Documents_Sources_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_Documents_Sources.CellContentClick

    End Sub

    Private Sub DataGridView_Documents_Sources_DoubleClick(sender As Object, e As EventArgs) Handles DataGridView_Documents_Sources.DoubleClick
        If DataGridView_Documents_Sources.SelectedCells.Count > 0 Then
            ViewSelectedDocInfo()
        End If
    End Sub


    Private Sub DataGridView_Documents_Sources_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles DataGridView_Documents_Sources.RowsAdded
        DataGridView_CountRows(DataGridView_Documents_Sources, Label_Sources_DocCountValue)
    End Sub

    Private Sub DataGridView_Documents_Sources_RowsRemoved(sender As Object, e As DataGridViewRowsRemovedEventArgs) Handles DataGridView_Documents_Sources.RowsRemoved
        DataGridView_CountRows(DataGridView_Documents_Sources, Label_Sources_DocCountValue)
    End Sub

    Function DataGridView_CountRows(passedDataGridView As DataGridView, Optional ByRef labelToUpdate As Label = Nothing) As Integer
        If labelToUpdate IsNot Nothing Then
            labelToUpdate.Text = passedDataGridView.Rows.Count
        End If
        Return passedDataGridView.Rows.Count
    End Function






    ' DOCUMENTS - DESTINATION - PLAIN TEXT CONTROLS
    ' =====================================================

    ' PLAIN TEXT - BUTTON - Default Values
    Private Sub Button_DestinationText_Default_Click(sender As Object, e As EventArgs) Handles Button_DestinationText_Default.Click
        SetDefaultUIValuesDocumentDestinationText()
    End Sub


    ' PLAIN TEXT - RADIO BUTTON - Same as Origin Directory
    Private Sub RadioButton_DestinationText_SameOriginFolder_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton_DestinationText_SameOriginFolder.CheckedChanged

    End Sub

    ' PLAIN TEXT - RADIO BUTTON - Custom
    Private Sub RadioButton_DestinationText_Custom_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton_DestinationText_Custom.CheckedChanged
        If RadioButton_DestinationText_Custom.Checked = True Then
            Panel_DestinationText_Directory.Enabled = True
            ' Populate the TextBox with path
            TextBox_DestinationText_Directory.Text = outputPlainTextDirectory
        Else
            Panel_DestinationText_Directory.Enabled = False
            ' Populate the TextBox with path
            TextBox_DestinationText_Directory.Text = ""
        End If
    End Sub

    ' PLAIN TEXT - TEXT BOX - Directory - ON TEXT CHANGE
    Private Sub TextBox_DestinationText_Directory_TextChanged(sender As Object, e As EventArgs) Handles TextBox_DestinationText_Directory.TextChanged

    End Sub


    ' PLAIN TEXT - TEXT BOX - Directory - ON LEAVE
    Private Sub TextBox_DestinationText_Directory_Leave(sender As Object, e As EventArgs) Handles TextBox_DestinationText_Directory.Leave
        ' Capitalize the First Character as thats usually a Drive Letter
        If TextBox_DestinationText_Directory.Text.Length > 0 Then
            TextBox_DestinationText_Directory.Text = Char.ToUpper(TextBox_DestinationText_Directory.Text(0)) & TextBox_DestinationText_Directory.Text.Substring(1)
        End If

        ' Check if the path does not contain a pipe (|), and replace it with a backslash (\)
        If TextBox_DestinationText_Directory.Text.Contains("|") Then
            TextBox_DestinationText_Directory.Text = TextBox_DestinationText_Directory.Text.Replace("|", "\")
        End If

        ' Check if the path does not end with a backslash, and add one if needed
        If Not TextBox_DestinationText_Directory.Text.EndsWith("\") Then
            TextBox_DestinationText_Directory.Text &= "\"
        End If

        ' Get the path from the TextBox
        Dim folderPath As String = TextBox_DestinationText_Directory.Text

        ' Check if the directory exists
        If Not String.IsNullOrWhiteSpace(folderPath) AndAlso Not IO.Directory.Exists(folderPath) Then
            ' Show a message or handle invalid directory case
            MessageBox.Show("The directory does not exist. Please enter a valid path.", "Invalid Directory", MessageBoxButtons.OK, MessageBoxIcon.Warning)

            ' Optionally, clear the textbox or focus it for the user to correct
            If Not outputPlainTextDirectory = "" Then
                TextBox_DestinationText_Directory.Text = outputPlainTextDirectory
            End If
            TextBox_DestinationText_Directory.Focus()
            TextBox_DestinationText_Directory.SelectAll()
        Else
            outputPlainTextDirectory = TextBox_DestinationText_Directory.Text
        End If
    End Sub



    ' PLAIN TEXT - BUTTON - Directory Browse
    Private Sub Button_DestinationText_Browse_Click(sender As Object, e As EventArgs) Handles Button_DestinationText_Browse.Click
        ' Create an instance of FolderBrowserDialog
        Using folderDialog As New FolderBrowserDialog
            ' Set a description or prompt for the dialog
            folderDialog.Description = "Select a folder"
            ' Optional: set the root folder (e.g., MyComputer or a specific folder)
            folderDialog.RootFolder = Environment.SpecialFolder.MyComputer
            ' Optional: set the selected path if you want to start at a specific directory
            folderDialog.SelectedPath = "C:\"

            ' Show the dialog and check if the user clicked OK
            If folderDialog.ShowDialog() = DialogResult.OK Then
                ' Set Global Variable 
                outputPlainTextDirectory = folderDialog.SelectedPath

                ' Populate the TextBox with path
                TextBox_DestinationText_Directory.Text = outputPlainTextDirectory

                ' Trigger the leave event
                TextBox_DestinationText_Directory_Leave(TextBox_DestinationText_Directory, EventArgs.Empty)
            End If
        End Using
    End Sub

    ' PLAIN TEXT - RADIO BUTTON - Same as Origin File Name
    Private Sub RadioButton_DestinationText_SameOriginFile_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton_DestinationText_SameOriginFile.CheckedChanged

    End Sub

    ' PLAIN TEXT - RADIO BUTTON - Prepend File Name
    Private Sub RadioButton_DestinationText_PrependFilename_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton_DestinationText_PrependFilename.CheckedChanged
        If RadioButton_DestinationText_PrependFilename.Checked = True Then
            Panel_DestinationText_Filename.Enabled = True
            TextBox_DestinationText_Filename.Text = outputPlainTextFileNameOrAppend
        Else
            Panel_DestinationText_Filename.Enabled = False
            TextBox_DestinationText_Filename.Text = ""
        End If
    End Sub

    ' PLAIN TEXT - RADIO BUTTON - Append File Name
    Private Sub RadioButton_DestinationText_AppendFilename_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton_DestinationText_AppendFilename.CheckedChanged
        If RadioButton_DestinationText_AppendFilename.Checked = True Then
            Panel_DestinationText_Filename.Enabled = True
            TextBox_DestinationText_Filename.Text = outputPlainTextFileNameOrAppend
        Else
            Panel_DestinationText_Filename.Enabled = False
            TextBox_DestinationText_Filename.Text = ""
        End If
    End Sub

    ' PLAIN TEXT - RADIO BUTTON - Custom File Name
    Private Sub RadioButton_DestinationText_CustomFilename_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton_DestinationText_CustomFilename.CheckedChanged
        If RadioButton_DestinationText_CustomFilename.Checked = True Then
            Panel_DestinationText_Filename.Enabled = True
            TextBox_DestinationText_Filename.Text = outputPlainTextFileNameOrAppend
        Else
            Panel_DestinationText_Filename.Enabled = False
            TextBox_DestinationText_Filename.Text = ""
        End If
    End Sub

    ' PLAIN TEXT - TEXT BOX - File Name - ON TEXT CHANGE
    Private Sub TextBox_DestinationText_Filename_TextChanged(sender As Object, e As EventArgs) Handles TextBox_DestinationText_Filename.TextChanged

    End Sub

    ' PLAIN TEXT - TEXT BOX - File Name - ON LEAVE
    Private Sub TextBox_DestinationText_Filename_Leave(sender As Object, e As EventArgs) Handles TextBox_DestinationText_Filename.Leave
        If Not TextBox_DestinationText_Filename.Text = "" Then
            outputPlainTextFileNameOrAppend = TextBox_DestinationText_Filename.Text
        End If
    End Sub



    ' DOCUMENTS - DESTINATION - METADATA CONTROLS
    ' =====================================================

    ' METADATA - BUTTON - Default Values
    Private Sub Button_DestinationMetadata_Default_Click(sender As Object, e As EventArgs) Handles Button_DestinationMetadata_Default.Click
        SetDefaultUIValuesDocumentDestinationMetadata()
    End Sub


    ' METADATA - CHECKBOX - Generate Metadata
    Private Sub CheckBox_DestinationMetadata_GenerateMetadata_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_DestinationMetadata_GenerateMetadata.CheckedChanged
        If CheckBox_DestinationMetadata_GenerateMetadata.Checked = True Then
            Panel1.Enabled = True
        Else
            Panel1.Enabled = False
        End If
    End Sub

    ' METADATA - RADIO BUTTON - Same as Origin Directory
    Private Sub RadioButton_DestinationMetadata_SameOriginFolder_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton_DestinationMetadata_SameOriginFolder.CheckedChanged

    End Sub

    ' METADATA - RADIO BUTTON - Same as Plain Text
    Private Sub RadioButton_DestinationMetadata_SameAsPlainText_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton_DestinationMetadata_SameAsPlainText.CheckedChanged

    End Sub

    ' METADATA - RADIO BUTTON - Custom Directory
    Private Sub RadioButton_DestinationMetadata_Custom_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton_DestinationMetadata_Custom.CheckedChanged
        If RadioButton_DestinationMetadata_Custom.Checked = True Then
            Panel_DestinationMetadata_Directory.Enabled = True
            TextBox_DestinationMetadata_Directory.Text = outputMetadataDirectory
        Else
            Panel_DestinationMetadata_Directory.Enabled = False
            TextBox_DestinationMetadata_Directory.Text = ""
        End If
    End Sub

    ' METADATA - TEXT BOX - Custom Directory - ON TEXT CHANGE
    Private Sub TextBox_DestinationMetadata_Directory_TextChanged(sender As Object, e As EventArgs) Handles TextBox_DestinationMetadata_Directory.TextChanged

    End Sub


    ' METADATA - TEXT BOX - Custom Directory - ON LEAVE
    Private Sub TextBox_DestinationMetadata_Directory_Leave(sender As Object, e As EventArgs) Handles TextBox_DestinationMetadata_Directory.Leave
        ' Capitalize the First Character as thats usually a Drive Letter
        If TextBox_DestinationMetadata_Directory.Text.Length > 0 Then
            TextBox_DestinationMetadata_Directory.Text = Char.ToUpper(TextBox_DestinationMetadata_Directory.Text(0)) & TextBox_DestinationMetadata_Directory.Text.Substring(1)
        End If

        ' Check if the path does not contain a pipe (|), and replace it with a backslash (\)
        If TextBox_DestinationMetadata_Directory.Text.Contains("|") Then
            TextBox_DestinationMetadata_Directory.Text = TextBox_DestinationMetadata_Directory.Text.Replace("|", "\")
        End If

        ' Check if the path does not end with a backslash, and add one if needed
        If Not TextBox_DestinationMetadata_Directory.Text.EndsWith("\") Then
            TextBox_DestinationMetadata_Directory.Text &= "\"
        End If

        ' Get the path from the TextBox
        Dim folderPath As String = TextBox_DestinationMetadata_Directory.Text

        ' Check if the directory exists
        If Not String.IsNullOrWhiteSpace(folderPath) AndAlso Not IO.Directory.Exists(folderPath) Then
            ' Show a message or handle invalid directory case
            MessageBox.Show("The directory does not exist. Please enter a valid path.", "Invalid Directory", MessageBoxButtons.OK, MessageBoxIcon.Warning)

            ' Optionally, clear the textbox or focus it for the user to correct
            If Not outputPlainTextDirectory = "" Then
                TextBox_DestinationMetadata_Directory.Text = outputMetadataDirectory
            End If
            TextBox_DestinationMetadata_Directory.Focus()
            TextBox_DestinationMetadata_Directory.SelectAll()
        Else
            outputMetadataDirectory = TextBox_DestinationMetadata_Directory.Text
        End If
    End Sub


    ' METADATA - BUTTON - Custom Directory Browse
    Private Sub Button_DestinationMetadata_Browse_Click(sender As Object, e As EventArgs) Handles Button_DestinationMetadata_Browse.Click
        ' Create an instance of FolderBrowserDialog
        Using folderDialog As New FolderBrowserDialog
            ' Set a description or prompt for the dialog
            folderDialog.Description = "Select a folder"
            ' Optional: set the root folder (e.g., MyComputer or a specific folder)
            folderDialog.RootFolder = Environment.SpecialFolder.MyComputer
            ' Optional: set the selected path if you want to start at a specific directory
            folderDialog.SelectedPath = "C:\"

            ' Show the dialog and check if the user clicked OK
            If folderDialog.ShowDialog() = DialogResult.OK Then
                ' Set Global Variable 
                outputMetadataDirectory = folderDialog.SelectedPath

                ' Populate the TextBox with path
                TextBox_DestinationMetadata_Directory.Text = outputMetadataDirectory

                ' Trigger the leave event
                TextBox_DestinationMetadata_Directory_Leave(TextBox_DestinationMetadata_Directory, EventArgs.Empty)
            End If
        End Using
    End Sub






    ' OPTIONS - TEXT FILE OPTIONS
    ' =====================================================

    ' TEXT FILE - BUTTON - Default Values
    Private Sub Button_TextFile_Default_Click(sender As Object, e As EventArgs) Handles Button_TextFile_Default.Click
        SetDefaultUIValuesOptionsTextFile()
    End Sub


    ' TEXT FILE - CHECKBOXES - Include Page Numbers
    Private Sub CheckBox_TextFile_IncludePageNumbers_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_TextFile_IncludePageNumbers.CheckedChanged

    End Sub

    ' TEXT FILE - CHECKBOXES - Line Breaks Per Page
    Private Sub CheckBox_TextFile_LineBreaksPerPage_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_TextFile_LineBreaksPerPage.CheckedChanged
        If CheckBox_TextFile_LineBreaksPerPage.Checked = True Then
            Panel_LineBreaksPerPage.Enabled = True
        Else
            Panel_LineBreaksPerPage.Enabled = False
        End If
    End Sub

    ' TEXT FILE - DOMAINUPDOWN - Line Breaks Per Page
    Private Sub DomainUpDown_LineBreaksPerPage_SelectedItemChanged(sender As Object, e As EventArgs) Handles DomainUpDown_LineBreaksPerPage.SelectedItemChanged

    End Sub


    ' TEXT FILE - CHECKBOXES - Split Files by Page
    Private Sub CheckBox_TextFile_SplitFilesByPage_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_TextFile_SplitFilesByPage.CheckedChanged

    End Sub

    ' TEXT FILE - CHECKBOXES - Retain Table Structures
    Private Sub CheckBox_TextFile_RetainTableStructures_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_TextFile_RetainTableStructures.CheckedChanged
        If CheckBox_TextFile_RetainTableStructures.Checked = True Then
            Panel_Delimiter.Enabled = True
        Else
            Panel_Delimiter.Enabled = False
        End If
    End Sub

    ' TEXT FILE - CHECKBOXES - Reformat Large Text Blocks
    Private Sub CheckBox_TextFile_ReformatTextBlocks_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_TextFile_ReformatTextBlocks.CheckedChanged
        If CheckBox_TextFile_ReformatTextBlocks.Checked = True Then
            Panel_LineBreakPerSentences.Enabled = True
        Else
            Panel_LineBreakPerSentences.Enabled = False
        End If
    End Sub

    ' TEXT FILE - DOMAIN UP DOWN - Line Break Per Sentences
    Private Sub DomainUpDown_LineBreakPerSentences_SelectedItemChanged(sender As Object, e As EventArgs) Handles DomainUpDown_LineBreakPerSentences.SelectedItemChanged

    End Sub




    ' OPTIONS - METADATA COMMON OPTIONS
    ' =====================================================

    ' METADATA COMMON - BUTTON - Select All
    Private Sub Button_MetadataCommon_SelectAll_Click(sender As Object, e As EventArgs) Handles Button_MetadataCommon_SelectAll.Click
        Log("    Enabling All MetaData Common Values")
        SelectMetadataCommonValues(True)
    End Sub

    ' METADATA COMMON - BUTTON - None
    Private Sub Button_MetadataCommon_None_Click(sender As Object, e As EventArgs) Handles Button_MetadataCommon_None.Click
        Log("    Disabling All MetaData Common Values")
        SelectMetadataCommonValues(False)
    End Sub

    ' METADATA COMMON - BUTTON - Default
    Private Sub Button_MetadataCommon_Default_Click(sender As Object, e As EventArgs) Handles Button_MetadataCommon_Default.Click
        Log("    Disabling All MetaData Common Values")
        SelectMetadataCommonValues(False)
        SetDefaultUIValuesOptionsMetadataCommon()
    End Sub

    ' METADATA COMMON - CHECKBOXES - File Name
    Private Sub CheckBox_MetadataCommon_Filename_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_MetadataCommon_Filename.CheckedChanged

    End Sub

    ' METADATA COMMON - CHECKBOXES - File Type
    Private Sub CheckBox_MetadataCommon_FileType_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_MetadataCommon_FileType.CheckedChanged

    End Sub

    ' METADATA COMMON - CHECKBOXES - File Size
    Private Sub CheckBox_MetadataCommon_FileSize_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_MetadataCommon_FileSize.CheckedChanged

    End Sub

    ' METADATA COMMON - CHECKBOXES - Original Created Date
    Private Sub CheckBox_MetadataCommon_OriginalCreatedDate_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_MetadataCommon_OriginalCreatedDate.CheckedChanged

    End Sub

    ' METADATA COMMON - CHECKBOXES - Original Document Path
    Private Sub CheckBox_MetadataCommon_OriginalDocumentPath_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_MetadataCommon_OriginalDocumentPath.CheckedChanged

    End Sub

    ' METADATA COMMON - CHECKBOXES - Page Number
    Private Sub CheckBox_MetadataCommon_PageNumber_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_MetadataCommon_PageNumber.CheckedChanged

    End Sub

    ' METADATA COMMON - CHECKBOXES - Page Count
    Private Sub CheckBox_MetadataCommon_PageCount_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_MetadataCommon_PageCount.CheckedChanged

    End Sub

    ' METADATA COMMON - CHECKBOXES - Text File Created Date
    Private Sub CheckBox_MetadataCommon_TextFileCreatedDate_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_MetadataCommon_TextFileCreatedDate.CheckedChanged

    End Sub





    ' OPTIONS - METADATA CUSTOM OPTIONS
    ' =====================================================

    ' METADATA CUSTOM - TOOLSTRIP - Button 1
    Private Sub ToolStripButton6_Click(sender As Object, e As EventArgs) Handles ToolStripButton6.Click

    End Sub

    ' METADATA CUSTOM - TOOLSTRIP - Select / Deselect All
    Private Sub ToolStrip_MetadataCustom_Button_SelectAll_Click(sender As Object, e As EventArgs) Handles ToolStrip_MetadataCustom_Button_SelectAll.Click
        DataGridViewOptions_ToggleSelectAll()
    End Sub

    ' METADATA CUSTOM - TOOLSTRIP - Delete Selected
    Private Sub ToolStrip_MetadataCustom_Button_DeleteSelected_Click(sender As Object, e As EventArgs) Handles ToolStrip_MetadataCustom_Button_DeleteSelected.Click
        DataGridViewOptions_DeleteSelected()
    End Sub

    ' METADATA CUSTOM - TOOLSTRIP - Button 4
    Private Sub ToolStripButton9_Click(sender As Object, e As EventArgs)

    End Sub


    ' METADATA CUSTOM - DATAGRID VIEW
    Private Sub DataGridView_Options_MetadataCustom_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_Options_MetadataCustom.CellContentClick

    End Sub


    Sub DataGridViewOptions_DeleteSelected()
        ' Check if there are any selected rows
        If DataGridView_Options_MetadataCustom.SelectedRows.Count > 0 Then
            Dim answer = MessageBox.Show("Delete Selected Rows?", "Delete Selected Rows?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If answer = vbNo Then
                Exit Sub
            End If

            ' Use a reverse loop because modifying the collection while iterating can cause issues
            For i As Integer = DataGridView_Options_MetadataCustom.SelectedRows.Count - 1 To 0 Step -1
                Dim row As DataGridViewRow = DataGridView_Options_MetadataCustom.SelectedRows(i)

                ' Check if the row is not the uncommitted new row before removing
                If Not row.IsNewRow Then
                    DataGridView_Options_MetadataCustom.Rows.Remove(row)
                End If
            Next
            Log("Deleted Selected Rows from Metadata Custom Key/Value Pairs")
        Else
            MessageBox.Show("No Rows Selected to Delete" & vbCrLf & "Select a Row First", "No Rows Selected", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub



    Sub DataGridViewOptions_ToggleSelectAll()
        If dataGridViewMetadataCustom_AllSelected Then
            ' If all are currently selected, deselect all
            DataGridView_Options_MetadataCustom.ClearSelection()
            dataGridViewMetadataCustom_AllSelected = False
        Else
            ' If not all are selected, select all
            DataGridView_Options_MetadataCustom.SelectAll()
            dataGridViewMetadataCustom_AllSelected = True
        End If
    End Sub







    ' LOGGING TAB
    ' =====================================================

    Sub OpenLogFile(Optional logFilePath As String = "")
        Try
            ' If no custom log file path is provided, use the application's directory
            If logFilePath = "" Then
                logFilePath = IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "DocStrip_" & DateTime.Now.ToString("yyyy-MM-dd") & ".log")
            End If

            ' Check if the log file exists before attempting to open it
            If IO.File.Exists(logFilePath) Then
                ' Open the log file in Notepad
                Log("Opening Log File From: " & logFilePath)
                Process.Start("notepad.exe", logFilePath)
            Else
                ' Inform the user if the log file does not exist
                MessageBox.Show("Log file not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            Dim msg = "An error occurred while trying to open the log file." & Environment.NewLine & ex.Message
            Log(msg)
            MessageBox.Show(msg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



    Private Sub Button_Logging_ClearInAppLog_Click(sender As Object, e As EventArgs) Handles Button_Logging_ClearInAppLog.Click
        Dim msg = "Clear In-App Logs? This won't affect the Log File Itself, only the logs in memory"
        Dim answer = MessageBox.Show(msg, "Clear In-App Logs?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        Log(msg)
        If answer = vbYes Then
            Log("Logs Cleared from Memory")
            RichTextBox_Logging_Output.Clear()
        Else
            Log("Ansered: NO")
        End If
    End Sub



    Private Sub Button_Logging_ViewLogFile_Click(sender As Object, e As EventArgs) Handles Button_Logging_ViewLogFile.Click
        OpenLogFile()
    End Sub








    ' MAIN APP BOTTOM CONTROLS
    ' =====================================================
    ' CHECKBOX - LOGGING ENABLED
    Private Sub CheckBox_Main_LoggingEnabled_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_Main_LoggingEnabled.CheckedChanged
        If CheckBox_Main_LoggingEnabled.Checked = True Then
            'MessageBox.Show("Logging is now Disabled", "Logging Disabled", MessageBoxButtons.OK, MessageBoxIcon.Error)
            enableLogging = True
            Log("Logging is now Enabled")
        Else
            'MessageBox.Show("Logging is now Disabled", "Logging Disabled", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Log("Logging is now Disabled")
            enableLogging = False
        End If
    End Sub

    ' BUTTON - CONVERT
    Private Sub Button_Convert_Click(sender As Object, e As EventArgs) Handles Button_ConvertAll.Click
        convertSuccess = False
        ConvertDocumentSources_All()
        If convertSuccess = True Then
            MsgBox("Saved All Files as Plain Text")
        End If
        convertSuccess = False
    End Sub


    Private Sub Button_ConvertSelected_Click(sender As Object, e As EventArgs) Handles Button_ConvertSelected.Click
        convertSuccess = False
        ConvertDocumentSources_Selected()
        If convertSuccess = True Then
            MsgBox("Saved Selected Files as Plain Text")
        End If
        convertSuccess = False
    End Sub






    ' ===========================================================================
    ' ON FORM CLOSE
    ' ===========================================================================
    Private Sub FormMain_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dim msg = "Quit Application?"
        Dim answer = MessageBox.Show(msg, "Quit Application?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        Log(msg)
        If answer = vbNo Then
            e.Cancel = True
            Log("Answered: NO")
        Else
            Log("Answered: YES" & vbCrLf & vbCrLf)
        End If
    End Sub


End Class







' NOTES
' it should be able to handle
' - Word documents, both old 93' type, and newer docx type 
' - PDF documents 
' - text files
' - rtf files       ** the "Split by page number bust TRY to do this, otherwise, treat as whole page **
' - HTML            ** the "Split by page number must be ignored for this **
' - XML             ** the "Split by page number must be ignored for this **
' - JSON            ** the "Split by page number must be ignored for this **
' - CSV             ** the "Split by page number must be ignored for this **
' - Obsidian        ** the "Split by page number must be ignored for this **


