﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormTesting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.RichTextBox_TestingOutput = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox_PageCount = New System.Windows.Forms.TextBox()
        Me.RichTextBox_DocumentInfo = New System.Windows.Forms.RichTextBox()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.SuspendLayout()
        '
        'RichTextBox_TestingOutput
        '
        Me.RichTextBox_TestingOutput.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox_TestingOutput.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RichTextBox_TestingOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox_TestingOutput.Location = New System.Drawing.Point(0, 0)
        Me.RichTextBox_TestingOutput.Name = "RichTextBox_TestingOutput"
        Me.RichTextBox_TestingOutput.Size = New System.Drawing.Size(939, 473)
        Me.RichTextBox_TestingOutput.TabIndex = 0
        Me.RichTextBox_TestingOutput.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Page Count"
        '
        'TextBox_PageCount
        '
        Me.TextBox_PageCount.Location = New System.Drawing.Point(79, 12)
        Me.TextBox_PageCount.Name = "TextBox_PageCount"
        Me.TextBox_PageCount.Size = New System.Drawing.Size(60, 20)
        Me.TextBox_PageCount.TabIndex = 2
        '
        'RichTextBox_DocumentInfo
        '
        Me.RichTextBox_DocumentInfo.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox_DocumentInfo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RichTextBox_DocumentInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox_DocumentInfo.Location = New System.Drawing.Point(0, 0)
        Me.RichTextBox_DocumentInfo.Name = "RichTextBox_DocumentInfo"
        Me.RichTextBox_DocumentInfo.Size = New System.Drawing.Size(939, 118)
        Me.RichTextBox_DocumentInfo.TabIndex = 0
        Me.RichTextBox_DocumentInfo.Text = ""
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.SplitContainer1.Location = New System.Drawing.Point(13, 38)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.RichTextBox_DocumentInfo)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.RichTextBox_TestingOutput)
        Me.SplitContainer1.Size = New System.Drawing.Size(941, 599)
        Me.SplitContainer1.SplitterDistance = 120
        Me.SplitContainer1.TabIndex = 4
        '
        'FormTesting
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(966, 650)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.TextBox_PageCount)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FormTesting"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Document Information"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RichTextBox_TestingOutput As RichTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox_PageCount As TextBox
    Friend WithEvents RichTextBox_DocumentInfo As RichTextBox
    Friend WithEvents SplitContainer1 As SplitContainer
End Class
