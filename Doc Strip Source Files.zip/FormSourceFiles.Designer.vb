﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormManageSources
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView_ManageSources = New System.Windows.Forms.DataGridView()
        Me.Sequence = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Type = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Path = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox_ManageSources = New System.Windows.Forms.GroupBox()
        Me.Panel_ManageSources = New System.Windows.Forms.Panel()
        Me.ToolStrip_ManageSources = New System.Windows.Forms.ToolStrip()
        Me.ToolStrip_ManageSources_Button_AddFile = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip_ManageSources_Button_AddFolder = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip_ManageSources_Button_SelectAll = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip_ManageSources_Button_DeleteSelected = New System.Windows.Forms.ToolStripButton()
        Me.Button_ConvertAll = New System.Windows.Forms.Button()
        Me.Panel_Menustrip_ManageSources = New System.Windows.Forms.Panel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportSourceListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportSourceListToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.DataGridView_ManageSources, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_ManageSources.SuspendLayout()
        Me.Panel_ManageSources.SuspendLayout()
        Me.ToolStrip_ManageSources.SuspendLayout()
        Me.Panel_Menustrip_ManageSources.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView_ManageSources
        '
        Me.DataGridView_ManageSources.AllowUserToAddRows = False
        Me.DataGridView_ManageSources.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView_ManageSources.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView_ManageSources.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Sequence, Me.Type, Me.Path})
        Me.DataGridView_ManageSources.Location = New System.Drawing.Point(11, 48)
        Me.DataGridView_ManageSources.Name = "DataGridView_ManageSources"
        Me.DataGridView_ManageSources.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView_ManageSources.Size = New System.Drawing.Size(754, 304)
        Me.DataGridView_ManageSources.TabIndex = 0
        '
        'Sequence
        '
        Me.Sequence.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Sequence.HeaderText = "Seq."
        Me.Sequence.Name = "Sequence"
        Me.Sequence.ReadOnly = True
        Me.Sequence.Width = 49
        '
        'Type
        '
        Me.Type.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Type.HeaderText = "Type"
        Me.Type.Name = "Type"
        Me.Type.ReadOnly = True
        Me.Type.Width = 50
        '
        'Path
        '
        Me.Path.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Path.HeaderText = "Path"
        Me.Path.Name = "Path"
        Me.Path.ReadOnly = True
        '
        'GroupBox_ManageSources
        '
        Me.GroupBox_ManageSources.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_ManageSources.Controls.Add(Me.Panel_ManageSources)
        Me.GroupBox_ManageSources.Controls.Add(Me.DataGridView_ManageSources)
        Me.GroupBox_ManageSources.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox_ManageSources.Location = New System.Drawing.Point(12, 35)
        Me.GroupBox_ManageSources.Name = "GroupBox_ManageSources"
        Me.GroupBox_ManageSources.Size = New System.Drawing.Size(776, 364)
        Me.GroupBox_ManageSources.TabIndex = 31
        Me.GroupBox_ManageSources.TabStop = False
        Me.GroupBox_ManageSources.Text = "Manage Sources"
        '
        'Panel_ManageSources
        '
        Me.Panel_ManageSources.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel_ManageSources.Controls.Add(Me.ToolStrip_ManageSources)
        Me.Panel_ManageSources.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel_ManageSources.Location = New System.Drawing.Point(11, 17)
        Me.Panel_ManageSources.Name = "Panel_ManageSources"
        Me.Panel_ManageSources.Size = New System.Drawing.Size(754, 25)
        Me.Panel_ManageSources.TabIndex = 40
        '
        'ToolStrip_ManageSources
        '
        Me.ToolStrip_ManageSources.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip_ManageSources.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStrip_ManageSources_Button_AddFile, Me.ToolStrip_ManageSources_Button_AddFolder, Me.ToolStrip_ManageSources_Button_SelectAll, Me.ToolStrip_ManageSources_Button_DeleteSelected})
        Me.ToolStrip_ManageSources.Location = New System.Drawing.Point(-9, 0)
        Me.ToolStrip_ManageSources.Name = "ToolStrip_ManageSources"
        Me.ToolStrip_ManageSources.Size = New System.Drawing.Size(104, 25)
        Me.ToolStrip_ManageSources.TabIndex = 41
        Me.ToolStrip_ManageSources.Text = "ToolStrip1"
        '
        'ToolStrip_ManageSources_Button_AddFile
        '
        Me.ToolStrip_ManageSources_Button_AddFile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStrip_ManageSources_Button_AddFile.Image = Global.DocStrip.My.Resources.Resources.icon_addFile
        Me.ToolStrip_ManageSources_Button_AddFile.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStrip_ManageSources_Button_AddFile.Name = "ToolStrip_ManageSources_Button_AddFile"
        Me.ToolStrip_ManageSources_Button_AddFile.Size = New System.Drawing.Size(23, 22)
        Me.ToolStrip_ManageSources_Button_AddFile.Text = "Add File"
        '
        'ToolStrip_ManageSources_Button_AddFolder
        '
        Me.ToolStrip_ManageSources_Button_AddFolder.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStrip_ManageSources_Button_AddFolder.Image = Global.DocStrip.My.Resources.Resources.icon_addFolder
        Me.ToolStrip_ManageSources_Button_AddFolder.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStrip_ManageSources_Button_AddFolder.Name = "ToolStrip_ManageSources_Button_AddFolder"
        Me.ToolStrip_ManageSources_Button_AddFolder.Size = New System.Drawing.Size(23, 22)
        Me.ToolStrip_ManageSources_Button_AddFolder.Text = "Add Folder"
        '
        'ToolStrip_ManageSources_Button_SelectAll
        '
        Me.ToolStrip_ManageSources_Button_SelectAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStrip_ManageSources_Button_SelectAll.Image = Global.DocStrip.My.Resources.Resources.icon_selectAllDeselectAll
        Me.ToolStrip_ManageSources_Button_SelectAll.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStrip_ManageSources_Button_SelectAll.Name = "ToolStrip_ManageSources_Button_SelectAll"
        Me.ToolStrip_ManageSources_Button_SelectAll.Size = New System.Drawing.Size(23, 22)
        Me.ToolStrip_ManageSources_Button_SelectAll.Text = "Select / Deselect All"
        '
        'ToolStrip_ManageSources_Button_DeleteSelected
        '
        Me.ToolStrip_ManageSources_Button_DeleteSelected.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStrip_ManageSources_Button_DeleteSelected.Image = Global.DocStrip.My.Resources.Resources.icon_delete
        Me.ToolStrip_ManageSources_Button_DeleteSelected.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStrip_ManageSources_Button_DeleteSelected.Name = "ToolStrip_ManageSources_Button_DeleteSelected"
        Me.ToolStrip_ManageSources_Button_DeleteSelected.Size = New System.Drawing.Size(23, 22)
        Me.ToolStrip_ManageSources_Button_DeleteSelected.Text = "Delete Selected"
        '
        'Button_ConvertAll
        '
        Me.Button_ConvertAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_ConvertAll.Location = New System.Drawing.Point(734, 413)
        Me.Button_ConvertAll.Name = "Button_ConvertAll"
        Me.Button_ConvertAll.Size = New System.Drawing.Size(54, 22)
        Me.Button_ConvertAll.TabIndex = 171
        Me.Button_ConvertAll.Text = "Close"
        Me.Button_ConvertAll.UseVisualStyleBackColor = True
        '
        'Panel_Menustrip_ManageSources
        '
        Me.Panel_Menustrip_ManageSources.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.Panel_Menustrip_ManageSources.Controls.Add(Me.MenuStrip1)
        Me.Panel_Menustrip_ManageSources.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel_Menustrip_ManageSources.Location = New System.Drawing.Point(0, 0)
        Me.Panel_Menustrip_ManageSources.Name = "Panel_Menustrip_ManageSources"
        Me.Panel_Menustrip_ManageSources.Size = New System.Drawing.Size(800, 29)
        Me.Panel_Menustrip_ManageSources.TabIndex = 172
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 29)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ImportSourceListToolStripMenuItem, Me.ExportSourceListToolStripMenuItem, Me.ToolStripSeparator1, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 24)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ImportSourceListToolStripMenuItem
        '
        Me.ImportSourceListToolStripMenuItem.Name = "ImportSourceListToolStripMenuItem"
        Me.ImportSourceListToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.ImportSourceListToolStripMenuItem.Text = "Import Source List"
        '
        'ExportSourceListToolStripMenuItem
        '
        Me.ExportSourceListToolStripMenuItem.Name = "ExportSourceListToolStripMenuItem"
        Me.ExportSourceListToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.ExportSourceListToolStripMenuItem.Text = "Export Source List"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(167, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'FormManageSources
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Panel_Menustrip_ManageSources)
        Me.Controls.Add(Me.Button_ConvertAll)
        Me.Controls.Add(Me.GroupBox_ManageSources)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FormManageSources"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Manage Sources"
        CType(Me.DataGridView_ManageSources, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_ManageSources.ResumeLayout(False)
        Me.Panel_ManageSources.ResumeLayout(False)
        Me.Panel_ManageSources.PerformLayout()
        Me.ToolStrip_ManageSources.ResumeLayout(False)
        Me.ToolStrip_ManageSources.PerformLayout()
        Me.Panel_Menustrip_ManageSources.ResumeLayout(False)
        Me.Panel_Menustrip_ManageSources.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView_ManageSources As DataGridView
    Friend WithEvents Sequence As DataGridViewTextBoxColumn
    Friend WithEvents Type As DataGridViewTextBoxColumn
    Friend WithEvents Path As DataGridViewTextBoxColumn
    Friend WithEvents GroupBox_ManageSources As GroupBox
    Friend WithEvents Panel_ManageSources As Panel
    Friend WithEvents ToolStrip_ManageSources As ToolStrip
    Friend WithEvents ToolStrip_ManageSources_Button_AddFile As ToolStripButton
    Friend WithEvents ToolStrip_ManageSources_Button_AddFolder As ToolStripButton
    Friend WithEvents ToolStrip_ManageSources_Button_SelectAll As ToolStripButton
    Friend WithEvents ToolStrip_ManageSources_Button_DeleteSelected As ToolStripButton
    Friend WithEvents Button_ConvertAll As Button
    Friend WithEvents Panel_Menustrip_ManageSources As Panel
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ImportSourceListToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExportSourceListToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
End Class
