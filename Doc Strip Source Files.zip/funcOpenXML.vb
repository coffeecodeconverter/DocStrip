﻿

Imports DocumentFormat.OpenXml.ExtendedProperties
Imports DocumentFormat.OpenXml.Packaging
Imports DocumentFormat.OpenXml.Wordprocessing
Imports System.Text
Imports Microsoft.VisualBasic
Imports DocumentFormat.OpenXml
Imports System.Text.RegularExpressions



Module funcOpenXML

    'Function GetWordDocumentTextPageCount(wordPath As String) As Integer
    '    ' Load the Word document
    '    Using wordDoc As WordprocessingDocument = WordprocessingDocument.Open(wordPath, False)
    '        ' Count the number of paragraphs (as a rough estimate for page count)
    '        Dim pageCount As Integer = wordDoc.MainDocumentPart.Document.Body.Elements(Of Paragraph)().Count()
    '        Return Math.Max(pageCount / 30, 1) ' Assume 30 paragraphs per page
    '    End Using
    'End Function




    Function GetWordDocumentInfo(wordPath As String) As String
        ' Load the Word document
        Using wordDoc As WordprocessingDocument = WordprocessingDocument.Open(wordPath, False)
            Dim properties = wordDoc.ExtendedFilePropertiesPart.Properties
            Dim infoBuilder As New StringBuilder()

            infoBuilder.AppendLine("Word Document Information:")
            infoBuilder.AppendLine("Title: " & If(properties.Template?.Text, "N/A"))
            infoBuilder.AppendLine("Manager: " & If(properties.Manager?.Text, "N/A"))
            infoBuilder.AppendLine("Company: " & If(properties.Company?.Text, "N/A"))
            infoBuilder.AppendLine("Pages: " & If(properties.Pages?.Text, "N/A"))
            infoBuilder.AppendLine("Words: " & If(properties.Words?.Text, "N/A"))
            infoBuilder.AppendLine("Characters: " & If(properties.Characters?.Text, "N/A"))
            infoBuilder.AppendLine("Paragraphs: " & If(properties.Paragraphs?.Text, "N/A"))
            infoBuilder.AppendLine("Application: " & If(properties.Application?.Text, "N/A"))
            infoBuilder.AppendLine("Application Version: " & If(properties.ApplicationVersion?.Text, "N/A"))

            Return infoBuilder.ToString()
        End Using
    End Function


    Function GetWordDocumentPageCount(wordDoc As WordprocessingDocument) As Integer
        Dim properties = wordDoc.ExtendedFilePropertiesPart.Properties
        Dim pageCount As Integer = 0

        If properties.Pages IsNot Nothing AndAlso Integer.TryParse(properties.Pages.Text, pageCount) Then
            Return pageCount
        Else
            Return 0 ' Return 0 if the page count cannot be determined
        End If
    End Function




    'Function GetWordDocumentTextPages(wordPath As String, Optional includePageNumbers As Boolean = False, Optional splitFilesPerPage As Boolean = False) As List(Of String)
    '    Dim documentPages As New List(Of String)()

    '    ' Load the Word document
    '    Using wordDoc As WordprocessingDocument = WordprocessingDocument.Open(wordPath, False)
    '        Dim paragraphs As IEnumerable(Of Paragraph) = wordDoc.MainDocumentPart.Document.Body.Elements(Of Paragraph)()
    '        Dim pageText As New StringBuilder()

    '        Dim paragraphTotal As Integer = paragraphs.Count
    '        Dim paragraphCount As Integer = 0
    '        Dim pageBreaks As Integer = 0

    '        Dim pageNum As Integer = 1
    '        Dim pageCount As Integer = GetWordDocumentPageCount(wordDoc)

    '        ' Iterate through all paragraphs
    '        For Each paragraph As Paragraph In paragraphs

    '            ' Extract text from the paragraph
    '            Dim extractedText As String = paragraph.InnerText
    '            'If Not extractedText = "" Then

    '            If includePageNumbers Then
    '                If Not extractedText = "" Then
    '                    pageText.Insert(0, $"Page: {pageNum} of {pageCount} {Environment.NewLine}")
    '                End If
    '            End If

    '            pageText.AppendLine(extractedText)
    '            documentPages.Add(pageText.ToString())  ' Add the page content to the list
    '            If pageNum = 1 Then
    '                pageNum += 1
    '            End If

    '            pageText.Clear()  ' Clear the buffer for the next page

    '            ' Check for last rendered page break or manual page break
    '            'If paragraph.Descendants(Of LastRenderedPageBreak)().Any() OrElse paragraph.Descendants(Of Break)().Any(Function(b) b.Type.Value = BreakValues.Page) Then
    '            If paragraph.Descendants(Of LastRenderedPageBreak)().Any() Then
    '                pageNum += 1
    '            End If

    '            'End If

    '            paragraphCount += 1
    '        Next

    '        ' Add remaining text as the last page
    '        If pageText.Length > 0 Then
    '            documentPages.Add(pageText.ToString())
    '        End If
    '    End Using

    '    ' Return the List of pages
    '    Return documentPages
    'End Function


    Function GetWordDocumentTextPages(wordPath As String, Optional includePageNumbers As Boolean = False, Optional splitFilesPerPage As Boolean = False, Optional reformatTextBlocks As Boolean = False, Optional reformatTextBlocksPerSentences As Integer = 0) As List(Of String)
        Dim documentPages As New List(Of String)()

        ' Load the Word document
        Using wordDoc As WordprocessingDocument = WordprocessingDocument.Open(wordPath, False)
            Dim body As Body = wordDoc.MainDocumentPart.Document.Body
            Dim pageText As New StringBuilder()
            Dim pageNum As Integer = 1

            ' Process headers
            For Each headerPart In wordDoc.MainDocumentPart.HeaderParts
                System.Windows.Forms.Application.DoEvents()
                Dim headerText As String = headerPart.Header.InnerText
                If Not headerText.Contains("TOC") AndAlso Not headerText.Contains("PAGEREF") Then
                    pageText.AppendLine(headerText.Trim())
                End If
            Next

            ' Get all elements (paragraphs, tables, etc.)
            Dim elements As IEnumerable(Of OpenXmlElement) = body.Elements()

            ' Iterate through all elements
            For Each element As OpenXmlElement In elements
                System.Windows.Forms.Application.DoEvents()

                ' Handle paragraphs
                If TypeOf element Is Paragraph Then
                    Dim extractedText As String = element.InnerText.Trim()

                    If Not extractedText.Contains("TOC") AndAlso Not extractedText.Contains("PAGEREF") Then
                        Dim numberingProps = element.GetFirstChild(Of NumberingProperties)()

                        ' Check if the paragraph is a list item
                        If numberingProps IsNot Nothing Then
                            pageText.AppendLine("● " & extractedText) ' Bullet each item on a new line
                        Else
                            ' Implement reformatting of text blocks
                            If reformatTextBlocks AndAlso reformatTextBlocksPerSentences > 0 Then
                                '' Split the text into sentences
                                'Dim sentences As String() = extractedText.Split(New Char() {"."c}, StringSplitOptions.RemoveEmptyEntries)
                                'Dim formattedText As New System.Text.StringBuilder()
                                'Dim sentenceCount As Integer = 0

                                '' Iterate over sentences and add line breaks
                                'For Each sentence As String In sentences
                                '    formattedText.Append(sentence.Trim() & ". ")
                                '    sentenceCount += 1

                                '    ' Add a line break after the specified number of sentences
                                '    If sentenceCount >= reformatTextBlocksPerSentences Then
                                '        formattedText.AppendLine()
                                '        formattedText.AppendLine()
                                '        sentenceCount = 0
                                '    End If
                                'Next

                                '' Append the formatted text to the page
                                'pageText.AppendLine(formattedText.ToString())

                                pageText.AppendLine(extractedText.ToString())
                            Else
                                ' Default behavior: append the text as is
                                pageText.Append(extractedText)
                            End If
                        End If
                    End If

                    ' Handle tables
                ElseIf TypeOf element Is Table Then
                    ProcessTable(CType(element, Table), pageText)
                End If

                ' Check for page breaks
                If element.Descendants(Of Break).Any Then
                    documentPages.Add(pageText.ToString().Trim())
                    pageText.Clear() ' Clear the buffer for the next page
                    pageNum += 1
                End If
            Next

            ' Process footers
            For Each footerPart In wordDoc.MainDocumentPart.FooterParts
                System.Windows.Forms.Application.DoEvents()
                Dim footerText As String = footerPart.Footer.InnerText
                pageText.AppendLine(footerText.Trim())
            Next

            ' Add a line break after all content before the next page
            If pageText.Length > 0 Then
                pageText.AppendLine()
                documentPages.Add(pageText.ToString().Trim())
            End If
        End Using

        ' Return the List of pages
        Return documentPages
    End Function





    Private Sub ProcessTable(table As Table, pageText As StringBuilder)
        For Each row As TableRow In table.Elements(Of TableRow)()
            Dim rowText As New StringBuilder()
            For Each cell As TableCell In row.Elements(Of TableCell)()
                Dim cellText As String = cell.InnerText
                rowText.Append(cellText.Trim()) ' Use tab to separate columns

                ' Check for nested tables
                Dim nestedTable As Table = cell.Descendants(Of Table)().FirstOrDefault()
                If nestedTable IsNot Nothing Then
                    Dim nestedText As New StringBuilder()
                    ProcessTable(nestedTable, nestedText) ' Process the nested table
                    rowText.Append(nestedText.ToString().Trim()) ' Append nested table text
                End If
            Next
            ' Trim the trailing tab and add a new line for the row
            pageText.AppendLine(rowText.ToString().TrimEnd())
        Next
    End Sub





    Sub GetWordDocumentParagraphsWithPageNumbers(wordPath As String)
        Using wordDoc As WordprocessingDocument = WordprocessingDocument.Open(wordPath, False)
            Dim paragraphInfos As New List(Of ParagraphInfo)()

            ' Get all paragraphs from the document
            Dim paragraphs = wordDoc.MainDocumentPart.Document.Descendants(Of Paragraph)()

            Dim pageIdx As Integer = 1
            For Each paragraph As Paragraph In paragraphs
                Dim run = paragraph.GetFirstChild(Of Run)()

                If run IsNot Nothing Then
                    Dim lastRenderedPageBreak = run.GetFirstChild(Of LastRenderedPageBreak)()
                    Dim pageBreak = run.GetFirstChild(Of Break)()

                    ' Increment the page number when a page break is detected
                    If lastRenderedPageBreak IsNot Nothing OrElse pageBreak IsNot Nothing Then
                        pageIdx += 1
                    End If
                End If

                ' Create a ParagraphInfo object to store paragraph and page number
                Dim info As New ParagraphInfo With {
                    .Paragraph = paragraph,
                    .PageNumber = pageIdx
                }

                paragraphInfos.Add(info)
            Next

            ' Output the results
            For Each info As ParagraphInfo In paragraphInfos
                FormMain.Log("Page {0}: '{1}'" & " " & info.PageNumber & " " & info.Paragraph.InnerText)
            Next
        End Using
    End Sub



End Module
