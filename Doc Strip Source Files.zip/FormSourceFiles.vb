﻿


Imports System.Text

Public Class FormManageSources



    ' ON FORM LOAD 
    Private Sub FormManageSources_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub




    ' MENUSTRIP - FILE > Import Source List
    Private Sub ImportSourceListToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ImportSourceListToolStripMenuItem.Click
        Using openFileDialog As New OpenFileDialog()
            openFileDialog.Filter = "CSV Files|*.csv"
            If openFileDialog.ShowDialog() = DialogResult.OK Then
                ImportFromCsv(openFileDialog.FileName)
            End If
        End Using
    End Sub


    ' MENUSTRIP - FILE > Export Source List
    Private Sub ExportSourceListToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExportSourceListToolStripMenuItem.Click
        Using saveFileDialog As New SaveFileDialog()
            saveFileDialog.Filter = "CSV Files|*.csv"
            saveFileDialog.FileName = FormMain.masterSourceListExportFileName
            If saveFileDialog.ShowDialog() = DialogResult.OK Then
                ExportToCsv(saveFileDialog.FileName)
            End If
        End Using
    End Sub


    ' MENUSTRIP - FILE > Exit
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub





    ' TOOLSTRIP - ADD FILE
    Private Sub ToolStrip_ManageSources_Button_AddFile_Click(sender As Object, e As EventArgs) Handles ToolStrip_ManageSources_Button_AddFile.Click
        Using openFileDialog As New OpenFileDialog()
            openFileDialog.Filter = "Supported Files|*.pdf;*.doc;*.docx;*.txt;*.rtf;*.csv;*.html;*.json;*.xml|All Files|*.*"
            openFileDialog.Multiselect = True ' Allow multiple file selection

            If openFileDialog.ShowDialog() = DialogResult.OK Then
                Dim duplicatesFound As Boolean = False

                ' Loop through each selected file
                For Each filePath In openFileDialog.FileNames
                    ' Check for duplicates before adding
                    If Not IsDuplicatePath(filePath) Then
                        Dim rowIndex As Integer = DataGridView_ManageSources.Rows.Add()
                        Dim row As DataGridViewRow = DataGridView_ManageSources.Rows(rowIndex)

                        row.Cells("Sequence").Value = rowIndex + 1
                        row.Cells("Type").Value = "File"
                        row.Cells("Path").Value = filePath

                        ' Update the global paths list
                        UpdateGlobalPaths()

                        FormMain.Log($"Manager - Added Source File: {filePath}")
                    Else
                        duplicatesFound = True
                    End If
                Next

                If duplicatesFound Then
                    MessageBox.Show("One or more files have already been added.", "Duplicate Entries", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End If
        End Using
    End Sub


    ' TOOLSTRIP - ADD FOLDER
    Private Sub ToolStrip_ManageSources_Button_AddFolder_Click(sender As Object, e As EventArgs) Handles ToolStrip_ManageSources_Button_AddFolder.Click
        Using folderBrowserDialog As New FolderBrowserDialog
            ' Let the user select folders multiple times.
            Dim selectedDirectories As New HashSet(Of String)

            Do
                ' Show the FolderBrowserDialog for folder selection.
                If folderBrowserDialog.ShowDialog() = DialogResult.OK Then
                    Dim folderPath As String = folderBrowserDialog.SelectedPath

                    ' Check for duplicates in DataGridView and in the selectedDirectories.
                    If IsDuplicatePath(folderPath) OrElse selectedDirectories.Contains(folderPath) Then
                        MessageBox.Show($"The folder '{folderPath}' has already been added.", "Duplicate Entry", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        ' Add the selected folder to the HashSet to ensure uniqueness in the current session.
                        selectedDirectories.Add(folderPath)

                        ' Add a new row to the DataGridView.
                        Dim rowIndex As Integer = DataGridView_ManageSources.Rows.Add()
                        Dim row As DataGridViewRow = DataGridView_ManageSources.Rows(rowIndex)

                        row.Cells("Sequence").Value = rowIndex + 1
                        row.Cells("Type").Value = "Folder"
                        row.Cells("Path").Value = folderPath

                        ' Update the global paths list
                        UpdateGlobalPaths()

                        FormMain.Log($"Manager - Added Source Folder: {folderPath}")

                    End If
                Else
                    ' Exit the loop if the user cancels the dialog.
                    Exit Do
                End If
            Loop While (MessageBox.Show("Add another folder?", "Select Folders", MessageBoxButtons.YesNo) = DialogResult.Yes)
        End Using
    End Sub




    ' TOOLSTRIP - SELECT / DESELECT ALL 
    Private Sub ToolStrip_ManageSources_Button_SelectAll_Click(sender As Object, e As EventArgs) Handles ToolStrip_ManageSources_Button_SelectAll.Click
        Dim allSelected As Boolean = DataGridView_ManageSources.Rows.Cast(Of DataGridViewRow)().All(Function(row) row.Selected)

        For Each row As DataGridViewRow In DataGridView_ManageSources.Rows
            row.Selected = Not allSelected
        Next

        Dim action As String = If(allSelected, "deselected", "selected")
    End Sub



    ' TOOLSTRIP - DELETE SELECTED
    Private Sub ToolStrip_ManageSources_Button_DeleteSelected_Click(sender As Object, e As EventArgs) Handles ToolStrip_ManageSources_Button_DeleteSelected.Click
        If DataGridView_ManageSources.SelectedRows.Count > 0 Then
            Dim confirmResult As DialogResult = MessageBox.Show("Are you sure you want to delete the selected rows?", "Confirm Delete", MessageBoxButtons.YesNo)
            If confirmResult = DialogResult.Yes Then
                ' Log and remove selected rows
                For Each row As DataGridViewRow In DataGridView_ManageSources.SelectedRows
                    FormMain.Log($"Deleting row: {row.Cells("Path").Value} of type {row.Cells("Type").Value}")
                    DataGridView_ManageSources.Rows.Remove(row)
                Next

                ' Reset sequence numbers
                For i As Integer = 0 To DataGridView_ManageSources.Rows.Count - 1
                    DataGridView_ManageSources.Rows(i).Cells("Sequence").Value = i + 1
                Next

                UpdateGlobalPaths()
            End If
        Else
            FormMain.Log("No rows selected for deletion.")
        End If
    End Sub




    ' DATAGRIDVIEW
    Private Sub DataGridView_ManageSources_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_ManageSources.CellContentClick

    End Sub

    ' DATAGRIDVIEW - ROWS ADDED
    Private Sub DataGridView_ManageSources_RowsAdded(sender As Object, e As DataGridViewRowsAddedEventArgs) Handles DataGridView_ManageSources.RowsAdded
        'FormMain.Log($"{e.RowCount} row(s) added.")
    End Sub

    ' DATAGRIDVIEW - ROWS REMOVED
    Private Sub DataGridView_ManageSources_RowsRemoved(sender As Object, e As DataGridViewRowsRemovedEventArgs) Handles DataGridView_ManageSources.RowsRemoved
        'FormMain.Log($"{e.RowCount} row(s) removed.")
    End Sub



    ' BUTTON - CLOSE
    Private Sub Button_ConvertAll_Click(sender As Object, e As EventArgs) Handles Button_ConvertAll.Click
        Me.Close()
    End Sub




    Private Function IsDuplicatePath(path As String) As Boolean
        ' Loop through the DataGridView to check for existing paths
        For Each row As DataGridViewRow In DataGridView_ManageSources.Rows
            If row.Cells("Path").Value IsNot Nothing AndAlso row.Cells("Path").Value.ToString() = path Then
                Return True ' Duplicate found
            End If
        Next
        Return False ' No duplicates found
    End Function



    Public Sub UpdateGlobalPaths()
        ' Clear the existing paths in the global list
        FormMain.GlobalPathsList.Clear()

        ' Iterate over DataGridView_ManageSources rows and add each Path to the global list
        For Each row As DataGridViewRow In DataGridView_ManageSources.Rows
            If row.Cells("Path").Value IsNot Nothing Then
                Dim path As String = row.Cells("Path").Value.ToString()
                FormMain.GlobalPathsList.Add(path)
            End If
        Next
    End Sub



    Private Sub ExportToCsv(filePath As String)
        Dim sb As New StringBuilder()
        ' Add header
        sb.AppendLine("Sequence,Type,Path")

        ' Add rows
        For Each row As DataGridViewRow In DataGridView_ManageSources.Rows
            If Not row.IsNewRow Then
                sb.AppendLine($"{row.Cells("Sequence").Value},{row.Cells("Type").Value},{row.Cells("Path").Value}")
            End If
        Next

        ' Write to file
        IO.File.WriteAllText(filePath, sb.ToString())
        FormMain.Log($"Exported to CSV: {filePath}")
    End Sub




    Private Sub ImportFromCsv(filePath As String)
        Dim confirmResult As DialogResult = MessageBox.Show("This will clear the current list. Do you want to continue?",
                                                             "Confirm Import",
                                                             MessageBoxButtons.YesNo,
                                                             MessageBoxIcon.Warning)

        If confirmResult = DialogResult.Yes Then
            Try
                Dim lines = IO.File.ReadAllLines(filePath)

                ' Check for headers
                If lines.Length = 0 OrElse Not lines(0).Equals("Sequence,Type,Path", StringComparison.OrdinalIgnoreCase) Then
                    MessageBox.Show("Invalid CSV - File must contain headers: Sequence, Type, and Path.", "Invalid CSV", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    FormMain.Log("Import failed: Invalid CSV headers.")
                    Return
                End If

                ' Clear existing data
                DataGridView_ManageSources.Rows.Clear()

                For i As Integer = 1 To lines.Length - 1 ' Skip header
                    Dim values = lines(i).Split(","c)

                    ' Ensure the row has the correct number of columns
                    If values.Length <> 3 Then
                        MessageBox.Show("Each row must contain exactly three values: Sequence, Type, Path.", "Invalid CSV Row", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        FormMain.Log("Import failed: Invalid row format.")
                        Return
                    End If

                    Dim rowIndex As Integer = DataGridView_ManageSources.Rows.Add()
                    Dim row As DataGridViewRow = DataGridView_ManageSources.Rows(rowIndex)

                    row.Cells("Sequence").Value = CInt(values(0))
                    row.Cells("Type").Value = values(1).Trim()
                    row.Cells("Path").Value = values(2).Trim()
                Next

                FormMain.Log($"Imported from CSV: {filePath}")
            Catch ex As Exception
                MessageBox.Show($"An error occurred while importing: {ex.Message}", "Import Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                FormMain.Log($"Import failed due to exception: {ex.Message}")
            End Try
        Else
            FormMain.Log("Import canceled by user.")
        End If
    End Sub







    ' ON FORM CLOSING 
    Private Sub FormManageSources_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

    End Sub


End Class
